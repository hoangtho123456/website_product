<?php include 'include/index-top.php';?>

<section class="l-visual">
  <div class="c-slider1 c-slider1-js">
    <div class="owl-carousel">
      <?php for($i = 0; $i < 2; $i++): ?>
      <div class="c-slider1__box1">
        <div class="img1">
          <img src="https://via.placeholder.com/1440x641.jpg" alt="slider">
        </div>

        <h1 class="t-title1">
          <img src="assets/images/title-slider.svg" alt="title">
        </h1>
        
        <section class="c-slider1__register">
          <div class="address">
            <h3>Cơ sở Ba Tháng Hai</h3>
            <p>594 Ba Tháng Hai, Quận 10, TP.HCM</p>
          </div>

          <div class="register">
            <a href="/">
              <h3>Đăng ký ngay</h3>
              <h3>0911 267 755</h3>
              <!-- <img src="assets/images/resister.png" alt="resister.png"> -->
            </a>
          </div>
        </section>
      </div>
      <?php endfor;?>
    </div>
  </div>
</section>

<section class="p-artboard2" id="artboard1">
  <section class="p-artboard2__box1">
    <div class="container">
      <h1 class="title1">
        HỘI THẢO - <strong>“CHUẨN BỊ TÂM THẾ CHO CON VÀO LỚP 1”</strong>
      </h1>

      <div class="box1">
        <div class="info1">
          <div class="info1-icon1">
            <img src="assets/images/iconmoon/icon1.svg" alt="icon1">
          </div>
          <p class="info1-text1">9:00 - 11:30, ngày 3 tháng 1 năm 2020</p>
        </div>

        <div class="info1">
          <div class="info1-icon1">
            <img src="assets/images/iconmoon/icon2.svg" alt="icon1">
          </div>
          <p class="info1-text1">Khách sạn New World - 76 Lê Lai, Ben Thanh, Q1, TP.HCM</p>
        </div>
      </div>
    </div>
  </section>
  
  <section class="p-artboard2__box2">
    <div class="container">
      <section class="inner1 row">
        <div class="col-sm-12 col-md-5 col-lg-4 box1 mb1SP">
          <div class="box1__inner">
            <div class="box1__title1">
              <h2>CHƯƠNG TRÌNH QUỐC TẾ TẠI VAS</h2>
            </div>

            <div class="box1__content1">
              <h3 class="box1__title2">Hội đồng chuyên môn VAS</h3>

              <ul class="list1">
                <li>Lộ trình học tập bậc Tiểu học </li>
                <li>Các hoạt động ngoại khóa</li>
                <li>Chăm sóc học sinh</li>
              </ul>

              <div class="icon1">
                <img src="assets/images/artboard2/icon1.svg" alt="icon1.svg">
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-7 col-lg-8 box1">
          <div class="box1__inner">
            <div class="box1__title1">
              <h2>CHUẨN BỊ TÂM THẾ<br>CHO CON VÀO LỚP 1</h2>
            </div>

            <div class="box1__content1">
              <h3 class="box1__title2">Ths/ Bác sĩ. Lê Thị Kim Dung <span>- Phòng khám đa khoa Care Plus</span></h3>

              <ul class="list1">
                <li>Thấu hiểu tâm lý trẻ 3 – 6 tuổi </li>
                <li>Dinh dưỡng cân bằng và hợp lý </li>
                <li>Chuẩn bị thể lực và trí lực để trẻ bước vào bậc tiểu học</li>
              </ul>

              <div class="icon1">
                <img src="assets/images/artboard2/icon2.svg" alt="icon2.svg">
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-5 col-lg-4 box2">
          <h3 class="title1">
            Phiếu Quà Tặng:
          </h3>

          <div class="box2__content1">
            <p><strong>01 bộ sách Cambridge hoặc 01 bộ sách Tiếng Việt, bộ sách Tiếng Anh và bộ Raz-kids hoặc 01 Samsung Galaxy Tab E 9.6</strong> khi đóng học phí tối thiểu 20 triệu đồng. </p>
          </div>

          <div class="p-artboard2__btn1">
            <a class="c-btn1" href="#">Đăng ký ngay</a>
          </div>
        </div>

        <div class="col-sm-12 col-md-7 col-lg-8 box2">
          <div class="p-artboard2__list1 p-artboard2__list1-js">
            <div class="owl-carousel">
              <?php 
                for($i = 0; $i < 3; $i++):
              ?>
              <div class="list1__card1">
                <div class="list1__img1">
                  <img src="assets/images/artboard2/img<?php echo $i + 1; ?>.png" alt="img">
                </div>
              </div>
              <?php endfor; ?>
            </div>
          </div>
        </div>                
      </section>
    </div>
  </section>
</section>

<section class="p-artboard1" id="artboard2">
  <div class="container">
    <div class="p-artboard1__box1">
      <section class="c-carousel1 c-carousel1-js">
        <div class="owl-carousel">
          <?php
            // $arr_title = ['BIZ FT-01', 'BIZ 01', 'BIZ 01', 'BIZ FT-01'];
            // $arr_img = ['img4.png', 'img5.png', 'img5.png', 'img4.png'];
            for($i = 0; $i < 6; $i++):
          ?>
          <div class="c-carousel1__card1 l-img1">
            <div class="c-carousel1__content1">
              <div class="c-carousel1__img1 img-hover">
                <img src="https://via.placeholder.com/321x234.jpg" alt="img">
              </div>
              <div class="c-carousel1__info1">
                <h3 class="title1">Campus Open Hours</h3>
                
                <div class="box1">
                  <div class="info1">
                    <div class="info1-icon1">
                      <img src="assets/images/iconmoon/icon1.svg" alt="icon1">
                    </div>
                    <p class="info1-text1">22 tháng Hai, 2019</p>
                  </div>
                  
                  <div class="info1">
                    <div class="info1-icon1">
                      <img src="assets/images/iconmoon/icon2.svg" alt="icon1">
                    </div>
                    <p class="info1-text1">Riverside Mega Campus/ Sala Mega Campus/ Ba Thang Hai Campus</p>
                  </div>
                  
                  <ul class="list1">
                    <li>Activity 1</li>
                    <li>Activity 2</li>
                    <li>Activity 3</li>
                    <li class="list1-child1">
                      <ul>
                        <li>Gift 1</li>
                        <li>Gift 2</li>
                        <li>Gift 3</li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="c-carousel1__info2">
                <a class="c-btn1" href="#">Đăng ký ngay</a>
              </div>
            </div>
          </div>
          <?php endfor; ?>
        </div>
      </section>
    </div>
  </div>
</section>

<section class="p-artboard3" id="artboard3">
  <section class="p-artboard3__box1">
    <div class="container">
      <div class="box1">
        <section class="form1">
          <h2 class="form1__title1">ĐĂNG KÝ NGAY ĐỂ ĐẶT CHỖ</h2>
          <form class="c-form1" action="">
            <div class="c-form1__info">
              <input type="text" placeholder="Họ và Tên">
            </div>
            <div class="c-form1__info">
              <input type="phone" placeholder="Số điện thoại">
            </div>
            <div class="c-form1__info">
              <input type="email" placeholder="Email">
            </div>
            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Đăng ký tham quan trường</option>
                <option value="都道府県">Đăng ký tham quan trường</option>
                <option value="都道府県">都道府県Đăng ký tham quan trường</option>
              </select>
            </div>

            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Tham dự sự kiện/hội thảo</option>
                <option value="都道府県">Tham dự sự kiện/hội thảo</option>
                <option value="都道府県">Tham dự sự kiện/hội thảo</option>
              </select>
            </div>

            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Chọn cơ sở để liên lạc</option>
                <option value="都道府県">Chọn cơ sở để liên lạc</option>
                <option value="都道府県">Chọn cơ sở để liên lạc</option>
              </select>
            </div>

            <a class="c-btn1" href="#">Xác Nhận</a>
          </form>
        </section>
        <div class="c-showPC img1">
          <img src="https://via.placeholder.com/562x361.jpg" alt="slider">
        </div>
      </div>
    </div>
  </section>
</section>

<?php include 'include/index-bottom.php';?>
