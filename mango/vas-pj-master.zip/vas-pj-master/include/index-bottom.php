
<!-- <div id="back-top" class="footer-btn-wrapper show">
  <a href="#page-header" class="button-to-top">
    <i class="icon icon-btn-top"></i>
  </a>
</div> -->
<div id="footer" class="c-footer">
</div>

</div>

<script type="text/javascript" src="assets/js/jquery.js" ></script>
<script type='text/javascript' src='assets/js/owl.carousel.min.js'></script> 
<script type="text/javascript" src="assets/js/slick.min.js"></script>
<script type='text/javascript' src='assets/js/imagesloaded.pkgd.min.js'></script> 
<script type="text/javascript" src="https://masonry.desandro.com/masonry.pkgd.js"></script>
<script type='text/javascript' src='assets/js/jquery.magnific-popup.min.js'></script> 

<script type='text/javascript' src='assets/js/script.js'></script>
<script type='text/javascript' src='assets/js/common.js'></script>
<script type='text/javascript' src='assets/js/script_owl.js'></script> 
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body></html>
