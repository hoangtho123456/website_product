<li id="li1"><a href="/">TRANG CHỦ</a></li>
<li id="li2"><a href="#artboard1">HỘI THẢO</a></li>
<li id="li3"><a href="#artboard2">SỰ KIỆN KHÁC</a></li>
<li id="li4"><a href="#artboard3">ĐĂNG KÝ</a></li>

<!-- <li class="children"  id="li4"><a href="./14_substainability.php">CỬA HÀNG</a>
  <ul>
    <li><a href="./15_our_project.php">Our Projects</a></li>
    <li><a href="./16_quater_report.php">Quarter Report</a></li>
    <li><a href="./17_foundation.php">Foundation</a></li>
  </ul>
</li> -->
