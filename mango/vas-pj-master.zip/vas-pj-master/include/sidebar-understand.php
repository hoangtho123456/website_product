<div class="widget widget-menu">
  <ul class="menu">
    <li class="active"><a href="03_founder.php">Understanding TH</a></li>
    <li><a href="04_vision.php">Annual report</a></li>
  </ul>
</div>
