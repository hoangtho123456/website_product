<div class="widget widget-menu">
  <ul class="menu">
    <li><a href="03_founder.php">Understanding TH</a></li>
    <li class="active"><a href="04_vision.php">Annual report</a></li>
  </ul>
</div>
