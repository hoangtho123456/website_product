<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VAS</title>
<!-- <link rel="shortcut icon" href="images/favicon.ico"> -->
<!-- <link href="https://fonts.googleapis.com/css?family=Montserrat:400,800&display=swap" rel="stylesheet"> -->
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="assets/fonts/awesome/css/fontawesome.min.css">
<link rel='stylesheet'  href='assets/css/main.css' type='text/css' media='all' />
<!-- <link rel="stylesheet" href="assets/css/edit.css"> -->
<!-- <script type="text/javascript" src="assets/js/jquery.js" ></script> -->
</head>

<body>
<div id="wrapper">
<span class="menu-btn overlay"> </span>

<header id="header" class="fixe" role="banner">
  <div class="container"> 
    <div class="th-container">
      <a href="./01_index.php" id="logo"> <img src="assets/images/logo.svg" alt="logo.svg"></a>
      <div class="wrap-menu-header mobile">
        <ul class="menu-top-header"> 
          <?php include 'mainmenu.php';?>
        </ul>

        <div class="showSP">
          <ul class="th-media1">
            <li class="media1__card1"><a href="/">
              <img src="assets/images/iconmoon/face.svg" alt="facebook">
              <!-- <i class="fab fa-facebook-f"></i> -->
            </a></li>
            <li class="media1__card1"><a href="/">
              <img src="assets/images/iconmoon/youtube.svg" alt="youtube">
              <!-- <i class="fab fa-youtube"></i> -->
            </a></li>
            <li class="media1__card1"><a href="#">
              <img src="assets/images/iconmoon/in.svg" alt="in.svg">
              <!-- <i class="fab fa-linkedin-in"></i> -->
            </a></li>
          </ul>

          <div class="th-translate">
            <a class="lang1 current" href="./index.php">VIE</a>
            <a class="lang1" href="./index-eng.php">ENG</a>
          </div>
        </div>
      </div>
      <div class="group-header">
        <ul class="showPC th-media1">
          <li class="media1__card1"><a href="/">
            <img src="assets/images/iconmoon/face.svg" alt="facebook">
            <!-- <i class="fab fa-facebook-f"></i> -->
          </a></li>
          <li class="media1__card1"><a href="/">
            <img src="assets/images/iconmoon/youtube.svg" alt="youtube">
            <!-- <i class="fab fa-youtube"></i> -->
          </a></li>
          <li class="media1__card1"><a href="#">
            <img src="assets/images/iconmoon/in.svg" alt="in.svg">
            <!-- <i class="fab fa-linkedin-in"></i> -->
          </a></li>
        </ul>

        <div class="showPC th-translate">
          <a class="lang1 current" href="./index.php">VIE</a>
          <a class="lang1" href="./index-eng.php">ENG</a>
        </div>
        <div class="item imenu"><span class="menu-btn x"><span></span></span> </div>
      </div>
    </div>
  </div>
</header>
<!-- End Mainmenu --> 

