<?php include 'include/index-top.php';?>

<section class="p-artboard1">
  <div class="container">
    <div class="p-artboard1__box1">
      <section class="c-carousel1 c-carousel1-js">
        <div class="owl-carousel">
          <?php
            // $arr_title = ['BIZ FT-01', 'BIZ 01', 'BIZ 01', 'BIZ FT-01'];
            // $arr_img = ['img4.png', 'img5.png', 'img5.png', 'img4.png'];
            for($i = 0; $i < 6; $i++):
          ?>
          <div class="c-carousel1__card1 l-img1">
            <div class="c-carousel1__content1">
              <div class="c-carousel1__img1 img-hover">
                <img src="https://via.placeholder.com/321x234.jpg" alt="img">
              </div>
              <div class="c-carousel1__info1">
                <h3 class="title1">Campus Open Hours</h3>
                
                <div class="box1">
                  <div class="info1">
                    <div class="info1-icon1">
                      <img src="assets/images/iconmoon/icon1.svg" alt="icon1">
                    </div>
                    <p class="info1-text1">22 tháng Hai, 2019</p>
                  </div>
                  
                  <div class="info1">
                    <div class="info1-icon1">
                      <img src="assets/images/iconmoon/icon2.svg" alt="icon1">
                    </div>
                    <p class="info1-text1">Riverside Mega Campus/ Sala Mega Campus/ Ba Thang Hai Campus</p>
                  </div>
                  
                  <ul class="list1">
                    <li>Activity 1</li>
                    <li>Activity 2</li>
                    <li>Activity 3</li>
                    <li class="list1-child1">
                      <ul>
                        <li>Gift 1</li>
                        <li>Gift 2</li>
                        <li>Gift 3</li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="c-carousel1__info2">
                <a class="c-btn1" href="#">Đăng ký ngay</a>
              </div>
            </div>
          </div>
          <?php endfor; ?>
        </div>
      </section>
    </div>
  </div>
</section>

<?php include 'include/index-bottom.php';?>
