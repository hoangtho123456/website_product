<section class="c-breadcrumbs">
    <div class="container">
        <span class="item"><a href="#">Home</a></span>
        <span class="item"><a href="#">About us</a></span> 
        <span class="item">Founder</span>
    </div>
</section>