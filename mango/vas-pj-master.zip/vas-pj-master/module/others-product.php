<div class="c-product2">
  <div class="container">
    <h2 class="c-title-special2">Sản phẩm khác của <strong>BIZNER</strong></h2>
    <div class="main-text">
      <p>BIZNER chú trọng vào cả chất lượng của chi tiết bên trong sản phẩm mang đến món quà trang trọng trong các dịp đặc biệt.</p>
    </div>

    <section class="c-product2__list1">
      <?php 
        $arr_img = ['paint1.png', 'paint2.png'];
        $arr_title = ['Phụ kiện', 'Quà tặng'];
        $arr_text = ['Công nghệ sản xuất mực hoặc ruột thay thế được chú trọng nhằm tạo nên chất lượng tuyệt đối cho sản phẩm.',
          'Bao bì đóng gói sang trọng giúp BIZNER trở thành món quà tặng phù hợp trong nhiều dịp quan trọng.'];
        for($i = 0; $i < 2; $i++):
      ?>
      <div class="l-img1 list1__card1">
        <div class="list1__box1">
          <h3><?php echo $arr_title[$i];?></h3>
          <img class="bg-img1" src="assets/images/product1/small-logo.svg" alt="small-logo.svg">
        </div>
        
        <div class="list1__box2">
          <div class="list1__img1 img-hover">
            <img src="assets/images/product1/<?php echo $arr_img[$i];?>" alt="paint">
          </div>

          <div class="list1__info1">
            <?php echo $arr_text[$i];?>
          </div>
        </div>
        
        <div class="list1__btn1">
          <a class="c-btn1 c-btn1--type1" href="#">Xem thêm</a>
        </div>
      </div>
      <?php endfor; ?>
    </section>
  </div>
</div>