<div class="c-page">
    <ul class="c-page-numbers pagination">
        <li><a class="prev page-numbers"><i class="icon-arrow-1"></i></a></li>
        <li><a class="page-numbers">1</a></li>
        <li class=" active"><span class="page-numbers current  active">2</span></li>
        <li><a class="page-numbers">3</a></li>
        <li><a class="page-numbers  next"><i class="icon-arrow-2"></i></a></li>
    </ul>
</div>