<?php include 'include/index-top.php';?>

<section class="p-artboard3">
  <section class="p-artboard3__box1">
    <div class="container">
      <div class="box1">
        <section class="form1">
          <h2 class="form1__title1">ĐĂNG KÝ NGAY ĐỂ ĐẶT CHỖ</h2>
          <form class="c-form1" action="">
            <div class="c-form1__info">
              <input type="text" placeholder="Họ và Tên">
            </div>
            <div class="c-form1__info">
              <input type="phone" placeholder="Số điện thoại">
            </div>
            <div class="c-form1__info">
              <input type="email" placeholder="Email">
            </div>
            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Đăng ký tham quan trường</option>
                <option value="都道府県">Đăng ký tham quan trường</option>
                <option value="都道府県">都道府県Đăng ký tham quan trường</option>
              </select>
            </div>

            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Tham dự sự kiện/hội thảo</option>
                <option value="都道府県">Tham dự sự kiện/hội thảo</option>
                <option value="都道府県">Tham dự sự kiện/hội thảo</option>
              </select>
            </div>

            <div class="c-form1__info">
              <select>
                <option value="Đăng ký tham quan trường">Chọn cơ sở để liên lạc</option>
                <option value="都道府県">Chọn cơ sở để liên lạc</option>
                <option value="都道府県">Chọn cơ sở để liên lạc</option>
              </select>
            </div>

            <a class="c-btn1" href="#">Xác Nhận</a>
          </form>
        </section>
        <div class="c-showPC img1">
          <img src="https://via.placeholder.com/562x361.jpg" alt="slider">
        </div>
      </div>
    </div>
  </section>
</section>

<?php include 'include/index-bottom.php';?>
