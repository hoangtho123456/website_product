jQuery(document).ready(function($) {
  /*=================================================*/
  $('.c-slider1-js .owl-carousel').owlCarousel({
    loop:true,
    autoWidth: false,
    margin: 0,
    items: 1,
    nav: true,
    dots: false,
    lazyLoad:true,
    // navContainerClass: 'c-slider1__control1',
    navText: ['<i class="icon icon-prev" aria-hidden="true"></i>', 
     '<i class="icon icon-next" aria-hidden="true"></i>'],
    navClass: ['c-arrow1 c-arrow1-prev1','c-arrow1 c-arrow1-next1'],
    responsive: {}
  });
  /*=================================================*/
  $('.c-carousel1-js .owl-carousel').owlCarousel({
    // autoplay: true,
    // autoplayTimeout: 10000,
    // autoplaySpeed: 1000,
    loop:true,
    autoWidth: false,
    margin: 0,
    items: 1,
    nav: true,
    dots: false,
    //video: true,
    lazyLoad:true,
    //navContainerClass: 'c-slider1__control1',
    navText: ['<i class="icon icon-prev" aria-hidden="true"></i>', 
    '<i class="icon icon-next" aria-hidden="true"></i>'],
    navClass: ['c-arrow1 c-arrow1-prev1','c-arrow1 c-arrow1-next1'],
    responsive: {
      768: {
        items: 2,
        margin: 24
      },
      992: {
        items: 3,
        margin: 44
      }
    } 
  });
  /*=================================================*/
  $('.p-artboard2__list1-js .owl-carousel').owlCarousel({
    // autoplay: true,
    // autoplayTimeout: 10000,
    // autoplaySpeed: 1000,
    loop:false,
    autoWidth: false,
    margin: 0,
    items: 2,
    nav: false,
    dots: false,
    //video: true,
    lazyLoad:true,
    //navContainerClass: 'c-slider1__control1',
    // navText: ['<i class="icon icon-prev" aria-hidden="true"></i>', 
    // '<i class="icon icon-next" aria-hidden="true"></i>'],
    // navClass: ['c-arrow1 c-arrow1-prev1','c-arrow1 c-arrow1-next1'],
    responsive: {
      768: {
        items: 2,
        margin: 24
      },
      992: {
        items: 3,
        margin: 74
      }
    } 
  });
  /*=================================================*/
  /**-------------------------------------------------
  *action: smooth scrolling
  *source link: https://css-tricks.com/snippets/jquery/smooth-scrolling/ 
  -------------------------------------------------*/
  $('.menu-top-header li a[href*="#"]')
    // Remove links that don't actually link to anything
    .not('[href="#"]')
    .not('[href="#0"]')
    .click(function(event) {
      // On-page links
      if (
        location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') 
        && 
        location.hostname == this.hostname
      ) {
        // Figure out element to scroll to
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        // Does a scroll target exist?
        if (target.length) {
          // Only prevent default if animation is actually gonna happen
          event.preventDefault();
          $('html, body').animate({
            scrollTop: target.offset().top - 50
          }, 1000, function() {
            // Callback after animation
            // Must change focus!
            var $target = $(target);
            $target.focus();
            if ($target.is(":focus")) { // Checking if the target was focused
              return false;
            } else {
              $target.attr('tabindex','-1'); // Adding tabindex for elements not focusable
              $target.focus(); // Set focus again
            };
          });
        }
      }
  });
});
