<?php include 'include/index-top.php';?>

<section class="p-artboard2">
  <section class="p-artboard2__box1">
    <div class="container">
      <h1 class="title1">
        HỘI THẢO - <strong>“CHUẨN BỊ TÂM THẾ CHO CON VÀO LỚP 1”</strong>
      </h1>

      <div class="box1">
        <div class="info1">
          <div class="info1-icon1">
            <img src="assets/images/iconmoon/icon1.svg" alt="icon1">
          </div>
          <p class="info1-text1">9:00 - 11:30, ngày 3 tháng 1 năm 2020</p>
        </div>

        <div class="info1">
          <div class="info1-icon1">
            <img src="assets/images/iconmoon/icon2.svg" alt="icon1">
          </div>
          <p class="info1-text1">Khách sạn New World - 76 Lê Lai, Ben Thanh, Q1, TP.HCM</p>
        </div>
      </div>
    </div>
  </section>
  
  <section class="p-artboard2__box2">
    <div class="container">
      <section class="inner1 row">
        <div class="col-sm-12 col-md-5 col-lg-4 box1 mb1SP">
          <div class="box1__inner">
            <div class="box1__title1">
              <h2>CHƯƠNG TRÌNH QUỐC TẾ TẠI VAS</h2>
            </div>

            <div class="box1__content1">
              <h3 class="box1__title2">Hội đồng chuyên môn VAS</h3>

              <ul class="list1">
                <li>Lộ trình học tập bậc Tiểu học </li>
                <li>Các hoạt động ngoại khóa</li>
                <li>Chăm sóc học sinh</li>
              </ul>

              <div class="icon1">
                <img src="assets/images/artboard2/icon1.svg" alt="icon1.svg">
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-7 col-lg-8 box1">
          <div class="box1__inner">
            <div class="box1__title1">
              <h2>CHUẨN BỊ TÂM THẾ<br>CHO CON VÀO LỚP 1</h2>
            </div>

            <div class="box1__content1">
              <h3 class="box1__title2">Ths/ Bác sĩ. Lê Thị Kim Dung <span>- Phòng khám đa khoa Care Plus</span></h3>

              <ul class="list1">
                <li>Thấu hiểu tâm lý trẻ 3 – 6 tuổi </li>
                <li>Dinh dưỡng cân bằng và hợp lý </li>
                <li>Chuẩn bị thể lực và trí lực để trẻ bước vào bậc tiểu học</li>
              </ul>

              <div class="icon1">
                <img src="assets/images/artboard2/icon2.svg" alt="icon2.svg">
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-12 col-md-5 col-lg-4 box2">
          <h3 class="title1">
            Phiếu Quà Tặng:
          </h3>

          <div class="box2__content1">
            <p><strong>01 bộ sách Cambridge hoặc 01 bộ sách Tiếng Việt, bộ sách Tiếng Anh và bộ Raz-kids hoặc 01 Samsung Galaxy Tab E 9.6</strong> khi đóng học phí tối thiểu 20 triệu đồng. </p>
          </div>

          <div class="p-artboard2__btn1">
            <a class="c-btn1" href="#">Đăng ký ngay</a>
          </div>
        </div>

        <div class="col-sm-12 col-md-7 col-lg-8 box2">
          <div class="p-artboard2__list1 p-artboard2__list1-js">
            <div class="owl-carousel">
              <?php 
                for($i = 0; $i < 3; $i++):
              ?>
              <div class="list1__card1">
                <div class="list1__img1">
                  <img src="assets/images/artboard2/img<?php echo $i + 1; ?>.png" alt="img">
                </div>
              </div>
              <?php endfor; ?>
            </div>
          </div>
        </div>                
      </section>
    </div>
  </section>
</section>

<?php include 'include/index-bottom.php';?>
