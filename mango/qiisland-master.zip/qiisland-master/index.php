<?php include 'include/index-top.php';?>
  
  <style>
    .c-slider1__box1 {
      background-image: url(assets/images/banner1.jpg);
    }
    @media only screen and (max-width: 767px) {
      .c-slider1__box1 { 
        background-image: <?php echo 'url(assets/images/slider1-sp.jpg);' ?>;
      }
    }
  </style>

  <section id="fullpage">
    <div class="section fp-auto-height-responsive">
      <section class="l-visual animate-slider-js">
        <div class="c-slider1 c-slider1-js">
          <div class="c-slider1__box1">
            <!-- <div class="container"> -->
              <div class="box1">
                <h2 class="title1 a-hiddenTop">Đại đô thị cao cấp <br>kết nối Sài Gòn – Bình Dương</h2>
              </div>
            <!-- </div> -->
          </div>
        </div>
        <!-- <div data-menuanchor="intro" class="icon-scroll-wrap">
          <a href="#intro"><div class="icon-scroll"></div></a>
        </div> -->
      </section>
    </div>


<!-- <main class="l-main"> -->
  <?php include('section/section-toan1.php'); ?>
  <?php include('section/section2.php'); ?>
  <?php include('section/section3.php'); ?>
  <?php include('section/section-structure.php'); ?>
  <?php //include('section/phankhu.php'); ?>


  <!-- <?php //include('section/section4.php'); ?> -->
  <?php include('section/section5_new.php'); ?>
  <?php include('section/section6.php'); ?>
<!-- </main> -->
<?php include 'include/index-bottom.php';?>
