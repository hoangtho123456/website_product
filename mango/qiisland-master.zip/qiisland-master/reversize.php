<?php include 'include/index-top-1.php';?>
  
<main class="l-main p-reversize0">
  <section class="p-reversize1">
    <section class="p-reversize1__box1">
      <div class="p-reversize1__title1">
        <a href="./index.php#structure">
          <div class="img1">
            <img src="assets/images/reversize/icon-smart.png" alt="icon-smart.png">
          </div>
        </a>
        <h2 class="title1">Khu QI REVESIZE</h2>
        </a>
      </div>

      <ul class="p-reversize1__list1">
        <li><a href="/">townhouse - middle</a></li>
        <li><a href="/">Shophouse - middle</a></li>
        <li><a href="/">Shophouse - conrner</a></li>
      </ul>
    </section>

    <ul class="p-reversize1__list1 p-reversize1__list1--type1">
      <li><a href="/">townhouse - middle 1</a></li>
      <li><a href="/">townhouse - middle 2</a></li>
    </ul>
  </section>

  <section class="c-slider2 c-slider2-js">
    <div class="owl-carousel">
      <?php for($i = 0; $i < 2; $i++): ?>
      <div class="c-slider2__box1">
        <div class="img1">
          <img src="assets/images/reversize/banner1.jpg" alt="banner1">
        </div>

        <div class="box1">
          <h4 class="box1-title1">Khu KL1 ( Lô 26-45), KL2 (Lô 1-22), KL2 (Lô 25-47) KL3 (Lô 1-25). KL3 (28-53)</h4>
        </div>
      </div>
      <?php endfor; ?>
    </div>
  </section>

  <section class="p-reversize2">
    <div class="container">
      <div class="p-reversize2__box1">
        <h2 class="c-title3">Thông tin chi tiết</h2>

        <section class="box1">
          <div class="box1__element1">
            <h3 class="title1">Khu KL1 ( Lô 26-45), KL2 (Lô 1-22), 
            KL2 (Lô 25-47) KL3 (Lô 1-25). KL3 (28-53)</h3>
            <h4 class="title2">Diện tích: 5 x 20m2</h4>
          </div>

          <div class="box1__element2">
            <div class="list1 row">
              <div class="list1__card1 col-sm-6 col-lg-5">
                <span class="list1__title1">Tổng diện tích sàn:</span>
                <span class="list1__num1">309,5 m2</span>
              </div>

              <div class="list1__card1 col-sm-6 col-lg-7">
                <span class="list1__title1">Diện tích sàn tầng 3:</span>
                <span class="list1__num1">82 m2</span>
              </div>

              <div class="list1__card1 col-sm-6 col-lg-5">
                <span class="list1__title1">Diện tích sàn tầng 1:</span>
                <span class="list1__num1">62,5 m2</span>
              </div>
              
              <div class="list1__card1 col-sm-6 col-lg-7">
                <span class="list1__title1">Diện tích sàn Sân thượng:</span>
                <span class="list1__num1">82 m2</span>
              </div>

              <div class="list1__card1 col-sm-6 col-lg-5">
                <span class="list1__title1">Diện tích sàn tầng 2:</span>
                <span class="list1__num1">83 m2</span>
              </div>
            </div>
          </div>
        </section>
        <p class="note-text">(*) Lưu ý: Đây chỉ là thông số cho căn điển hình </p>
      </div>

      <div class="p-reversize2__box2">
        <h2 class="c-title3">Mặt bằng tầng</h2>

        <section class="p-reversize2__list1 row">
          <?php 
            $arr_title = ['Mặt bằng tầng 1', 'Mặt bằng tầng 2', 'Mặt bằng tầng 3',
            'Mặt bằng tầng sân thượng'];
            $arr_img = ['img1.png', 'img2.png', 'img3.png', 'img4.png'];
            for($i = 0; $i < 4; $i++): ?>
            <div class="col-sm-12 col-md-6 col-lg-6 list1__card1">
              <a class="list1__content1 p-img1-js" href="assets/images/reversize/<?php echo $arr_img[$i];?>">
                <h3 class="list1__title1"><?php echo $arr_title[$i]; ?></h3>
                
                <div class="list1__img1">
                  <img src="assets/images/reversize/<?php echo $arr_img[$i];?>" alt="img">
                </div>
              </a>
            </div>
          <?php endfor; ?>
        </section>
      </div>      
    </div>
  </section>
</main>

<?php include 'include/index-bottom-1.php';?>
