<section class="section p-top2 p-top2-new fp-auto-height-responsive animate-top2-js">
  <div class="p-top2__circle1">
    <img src="assets/images/1419.png" alt="1419.png">
  </div>
  <div class="p-top2__circle2">
    <img src="assets/images/bg-map2.png" alt="bg-map.png">
  </div>
  <div class="p-top2__content1 a-hiddenTop">
    <h2 class="c-title1 a-hiddenTop">SECTION LOCATION</h2>

    <div class="product-info-container" style="max-width: inherit;" >
      <div class="product-info-inner">
        <img onmouseover="clickProduct(this, 'assets/images/img-map.png')" id="product_info_image_id" src="assets/images/img-map.png" border="0" width="730" height="555" orgWidth="1920" orgHeight="1080" usemap="#product_info_image_name" alt="" />
        <map name="product_info_image_name" id="product_info_map_image">

          <area data-id="#block1" alt="A1" title="" href="javascript:void(0);" shape="poly" coords="268,479,113,421,56,368,57,337,219,268,411,371,411,403" style="outline:none;" onmouseover="clickProduct(this, 'assets/images/img-map-1.png')"/>
          <area data-id="#block2" alt="A1" title="" href="javascript:void(0);" shape="poly" coords="430,385,245,274,442,179,624,244,620,272" style="outline:none;" onmouseover="clickProduct(this, 'assets/images/img-map-2.png')"/>
          <area data-id="#block3" alt="A1" title="" href="javascript:void(0);" shape="poly" coords="240,274,170,238,201,162,269,139,327,139,434,179" style="outline:none;" onmouseover="clickProduct(this, 'assets/images/img-map-3.png')"/>
          <area data-id="#block4" alt="A1" title="" href="javascript:void(0);" shape="poly" coords="631,249,643,220,633,148,600,135,571,146,538,138,456,177" style="outline:none;" onmouseover="clickProduct(this, 'assets/images/img-map-4.png')"/>
          <area data-id="#block5" alt="A1" title="" href="javascript:void(0);" shape="poly" coords="429,107,434,147,522,144,542,136,568,144,603,135,621,142,623,124,528,122,487,107" style="outline:none;" onmouseover="clickProduct(this, 'assets/images/img-map-5.png')"/>
        </map>

      <!-- -------------------------- -->
        <div id="block1" class="product-point-container" style="left: 29%; top: 64%;">
          <div class="product-point-icon"></div>
          <div class="product-point-overflow">
            <div class="description-point">
              <div class="top-description-point">
                <h4 style="text-align: center;">Qi Riverside</h4>
              </div>
            </div>
          </div>
        </div>
        <div id="block2" class="product-point-container" style="left: 59%; top: 45%;">
          <div class="product-point-icon"></div>
          <div class="product-point-overflow">
            <div class="description-point">
              <div class="top-description-point">
                <h4 style="text-align: center;">Qi Park</h4>
              </div>
            </div>
          </div>
        </div>
        <div id="block3" class="product-point-container" style="left: 38%; top: 32%;">
          <div class="product-point-icon"></div>
          <div class="product-point-overflow">
            <div class="description-point">
              <div class="top-description-point">
                <h4 style="text-align: center;">Qi Central</h4>
              </div>
            </div>
          </div>
        </div>
        <div id="block4" class="product-point-container" style="left: 81%;top: 31%;">
          <div class="product-point-icon"></div>
          <div class="product-point-overflow">
            <div class="description-point">
              <div class="top-description-point">
                <h4 style="text-align: center;">Qi Commercial</h4>
              </div>
            </div>
          </div>
        </div>
        <div id="block5" class="product-point-container" style="left: 62%; top: 25%;">
          <div class="product-point-icon"></div>
          <div class="product-point-overflow">
            <div class="description-point">
              <div class="top-description-point">
                <h4 style="text-align: center;">Qi Avenue</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- <div class="dd-b-how-to-view">
         <span class="dd-icons"><span></span><span></span><span></span><span></span><span></span><span></span></span>
         <p>Vuốt ngang để xem toàn bộ</p>
      </div> -->

      <script type="text/javascript">
        function clickProduct(_this, _src) {
          if(jQuery( window ).width() > 767) {
            jQuery('#product_info_image_id').attr('src', _src);
            jQuery('.product-info-container').fadeIn();
            
            var id = jQuery(_this).data('id');
            
            jQuery('.product-info-container').find('.product-point-container').removeClass('point-hover');
            jQuery('.product-info-container').find('.product-point-container').find('.product-point-overflow').fadeOut();
            
            if(typeof id != 'undefined'){
              console.log(jQuery(id).hasClass('point-hover'));
              if (jQuery(id).hasClass('point-hover') === false) {
                jQuery(id).addClass('point-hover');
                jQuery(id).find('.product-point-overflow').fadeIn();
              }
            }
          }
        }
        jQuery(function(){
          if(jQuery( window ).width() > 767) {
            jQuery('.product-point-container').on('hover', function(){
              if (jQuery(this).hasClass('point-hover') === false) {
                jQuery(this).parents('.product-info-container').find('.product-point-container').removeClass('point-hover');
                jQuery(this).parents('.product-info-container').find('.product-point-container').find('.product-point-overflow').fadeOut();
                jQuery(this).addClass('point-hover');
                jQuery(this).find('.product-point-overflow').fadeIn();
              }
            })
          } else {
            jQuery('.product-point-container').on('click', function(){
              // var href = jQuery(this).find('.product-point-overflow a').attr('href');
              // console.log(href);
              // location.href = href;
            })
          }
        })
      </script>
    </div>
  </div>
</section>
