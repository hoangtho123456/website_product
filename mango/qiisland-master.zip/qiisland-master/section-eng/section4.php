<section class="section p-top4 animate-top4-js">
  <section class="c-showPC p-top4__content1">
    <section class="container p-top4__box1">
      <div class="box1">
        <!-- <div class="info1">top4-info1-js -->
        <?php for($i = 0; $i < 1; $i++): ?>
        <h4 class="info1__title1 top4-link1-js a-hiddenTop" data-bg="box1__bg<?php echo $i + 1;?>">Đơn vị hỗ trợ vay vốn</h4>
        
        <div class="info1__content1 top4-text1-js a-hiddenTop">
          <div class="img1">
            <img src="assets/images/logo-Vietbank.png" alt="logo">
          </div>
          <p>Được thành lập từ năm 2007, VietBank đã kiên trì với mục tiêu phát triển bền vững, phù hợp với nội lực để phục vụ khách hàng, đóng góp cho cộng đồng xã hội và tạo việc làm cho người lao động trong suốt quá trình hoạt động, VietBank của hiện tại đang tập trung đầu tư lớn cho các dự án công nghệ thông tin; con người để xây dựng nền tảng phục vụ cho chiến lược phát triển lâu dài</p>
        </div>
        <?php endfor; ?>
        <!-- </div> -->
      </div>
    </section>
    
    <div class="p-top4__bg1 top4-bg-js" data-bg="box1__bg1">
      <img src="assets/images/banner4.jpg" alt="banner4.jpg">
    </div>
    <!-- <div class="p-top4__bg1 top4-bg-js" data-bg="box1__bg2">
      <img src="assets/images/banner2.png" alt="banner4.jpg"></div>
    <div class="p-top4__bg1 top4-bg-js" data-bg="box1__bg3">
      <img src="assets/images/banner1.png" alt="banner4.jpg"></div> -->
  </section>

  <section class="c-showSP p-top4__contentSP1">
    <section class="p-top4__boxSP1">
      <div class="list1 top4-list1-js">
        <div class="owl-carousel">
          <?php for($i = 0; $i < 1; $i++): ?>
          <div class="list1__card1">
            <div class="list1__box1">
              <p class="info1__title1" data-bg="box1__bg<?php echo $i + 1;?>">Đơn vị hỗ trợ vay vốn</p>
              <div class="info1__content1">
                <div class="img1">
                  <img src="assets/images/logo-Vietbank.png" alt="logo">
                </div>
                <p>Được thành lập từ năm 2007, VietBank đã kiên trì với mục tiêu phát triển bền vững, phù hợp với nội lực để phục vụ khách hàng, đóng góp cho cộng đồng xã hội và tạo việc làm cho người lao động trong suốt quá trình hoạt động, VietBank của hiện tại đang tập trung đầu tư lớn cho các dự án công nghệ thông tin; con người để xây dựng nền tảng phục vụ cho chiến lược phát triển lâu dài</p>
              </div>
            </div>

            <div class="list1-bg1">
              <img src="assets/images/banner4.jpg" alt="banner4.jpg">
            </div>
          </div>
          <?php endfor; ?>
        </div>
      </div>
    </section>
  </section>
</section>
