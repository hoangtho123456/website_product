<style>
  .p-top1 {
    background-image: url(assets/images/bgslide1-pc.jpg);
  }
  @media only screen and (max-width: 767px) {
    .p-top1 { 
      background-image: <?php echo 'url(assets/images/bgslide1-sp.jpg);' ?>;
    }
  }
</style>

<section class="wrap-multi-slide section p-top1">
  <div class="container" >

    <div class="row">
      <div class="col-md-4">

        <div class="slick-slide-1">
          <?php 
          $arr_content = [
            "Luxury megacity - Qi island - is a peaceful green oasis connecting two most dynamic cities: Saigon and Binh Duong.",
            "Qi island is a perfect combination of modern architecture, bright green of pure nature and surrounding river.",
            "Qi island is the cozy home facilitated with smart, comfortable and classy living space for its residents.",
            "Qi island is the best choice for people who want to improve their quality of life with 3 golden connections: geographic connection, nature connection and technology connection."
          ];
          for($i=1;$i<=4;$i++){ ?>
          <div class="item">  
              <div class="desc">

                <p><?php echo $arr_content[$i - 1];?></p>

              </div>
          </div>
          <?php } ?>
        </div>

      </div>    
      <div class="col-md-8">


        <div class="row group-slide">
          <div class="col-4">
            <div class="slick-slide-2">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>   
          </div>  
          <div class="col-4">
            <div class="slick-slide-3">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>  
          </div> 
          <div class="col-4"> 
            <div class="slick-slide-4">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>   
          </div>      
        </div>        
        
      </div>    
    </div>

  </div>


  
  <script type='text/javascript' src='https://code.jquery.com/jquery-1.11.0.min.js'></script> 
<script type='text/javascript' src='https://kenwheeler.github.io/slick/slick/slick.js'></script> 


<script type="text/javascript">
// JavaScript Document
(function($){
    $(document).ready(function(){

        const $slider = $(".slick-slide-1");
        const $slider2 = $(".slick-slide-2");
        const $slider3 = $(".slick-slide-3");
        const $slider4 = $(".slick-slide-4");
        $slider.slick({
            dots: false,
            fade: true,
            infinite: true,
            autoplay:true,
            autoplaySpeed: 10000,
            slidesToShow: 1,
            slidesToScroll: 1,     
            asNavFor: '.slick-slide-2,.slick-slide-3,.slick-slide-4',       
        })


        $slider2.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,    
            asNavFor: '.slick-slide-1',       
        })  
        $slider3.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,   
            asNavFor: '.slick-slide-1',       
        })  
        $slider4.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1, 
            asNavFor: '.slick-slide-1',      
        })  


        function mouseWheel($slider) {
          $(window).on('wheel', { $slider: $slider }, mouseWheelHandler)
        }
        function mouseWheelHandler(event) {
          event.preventDefault()
          const $slider = event.data.$slider
          const delta = event.originalEvent.deltaY
          if(delta > 0) {
            $slider.slick('slickPrev')
          }
          else {
            $slider.slick('slickNext')
          }
        }



    }); 

})(jQuery); 
    
</script>
</section>

