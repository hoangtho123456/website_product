<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Qi Island</title>

<meta property="og:title" content="Qi Island" />
<meta property="og:image" content="assets/images/banner1.jpg" />

<link href="https://fonts.googleapis.com/css?family=Nunito+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap" rel="stylesheet">

<link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
<link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/fullpage.css">
<link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="assets/css/slick.css">
<link rel='stylesheet'  href='assets/css/main.css' type='text/css' media='all' />
<link rel="stylesheet" href="assets/new-carousel/carousel.css" />
<link rel='stylesheet'  href='assets/slick-multi/css/main.css' type='text/css' media='all' />
<!-- <script type="text/javascript" src="assets/js/jquery.js" ></script> -->
</head>

<body class="c-custom-nav">
  <div class="loading-wrap">
    <div class="loading-content">
      <div class="bg-loading-wrapper"></div>
      <div class="th-loading">
        <div class="logo-loading">
          <img src="assets/images/logoloading.png" alt="Island">
        </div>
      </div>
    </div>
  </div>

  <div class="wrapper">
    <header id="header" role="banner" class="fixe">
      <div class="container">
        <a href="#" id="logo" class="logo-size-js"> <!-- class="showSP" -->
          <img class="img1-js" src="assets/images/logo-island0.png" alt="Island">
          <img class="hidden img1-js" src="assets/images/logo-blue1.png" alt="Island">
          <img class="hidden img1-js" src="assets/images/logo-scroll-white.png" alt="Island">
        </a>

        <div class="wrap-menu-header">
          <div class="menu-top-header-box1">
            <ul class="menu-top-header">
              <li><a href="#intro">HOME</a></li>
              <li><a href="#map">Location</a></li>
              <li><a href="#utilities">Utilities</a></li>
              <li class="th-child">
                <a href="#structure">SECTIONS</a>
                <ul class="th-child-list1">
                  <li><a href="#">Qi CENTRAL</a></li>
                  <li><a href="#">Qi RIVERSIDE</a></li>
                  <li><a href="#">QI PARK</a></li>
                  <li><a href="#">QI COMMERCIAL</a></li>
                  <li><a href="#">QI AVENUE</a></li>
                </ul>
              </li>
              <li><a href="#gallery">GALLERY</a></li>
              <li><a href="#contact">Partners</a></li>
              <li><a href="#news">News</a></li>
              <li><a href="#contact">Contact</a></li>
              <li class="th-media">
                <ul class="th-media-list1">
                  <li class="img-h1"><a href="#">
                    <img src="assets/images/instagram.png" alt="instagram.png">
                  </a></li>
                  <li class="img-h1"><a href="https://www.facebook.com/Chudautu.Qiisland/">
                    <img src="assets/images/facebook.png" alt="facebook">
                  </a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>

        <div class="group-header">
          <div class="item imenu"><span class="menu-btn x"><span></span></span> </div>
        </div>

        <div class="th-translate">
          <div class="logo1">
            <!-- <img src="assets/images/global-logo.png" alt="global-logo"> -->
            <span class="icon-global"></span>
          </div>
          <a class="lang1" href="./index.php">VIE</a>
          <a class="lang1 current" href="./index-eng.php">ENG</a>
        </div>
      </div>
    </header>
<!-- End Mainmenu --> 

