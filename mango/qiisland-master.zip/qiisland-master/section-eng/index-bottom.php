<section class="c-footer section">
	<section class="c-footer__inner1">
		<section class="c-footer__content1">
			<section class="container c-footer__box1">
				<article class="box2">
					<h2 class="box2__title1">Investor and partners</h2>
					<div class="list2 f-list2-js">
						<div class="owl-carousel">
							<?php
							$arr_img = ['logo-t-f1.png', 'logo-t-f2.png', 'logo-t-f3.png', 'logo-t-f4.png'];
							$arr_imgsp = ['coop1-sp.png', 'coop2-sp.png', 'coop3-sp.png', 'logo-t-f4.png'];
							$arr_title = ['Project developer', 'Distributors',
								'Design consultancy', 'Financial support partner'];
							for($i = 0; $i < 4; $i++):
							if($i === 2): ?>
							<a class="list2__card1" href="#">
								<div class="list2__img1 list2__coop<?php echo $i + 1; ?>">
									<img class="c-showPC" src="assets/images/<?php echo $arr_img[$i]; ?>" alt="img">
									<img class="c-showSP" src="assets/images/<?php echo $arr_imgsp[$i]; ?>" alt="img">
								</div>
								<h5 class="list2__title1"><?php echo $arr_title[$i]; ?></h5>
							</a>
							<?php else: ?>
							<a class="list2__card1" href="#">
								<div class="list2__img1 list2__coop<?php echo $i + 1; ?>">
									<img class="c-showPC" src="assets/images/<?php echo $arr_img[$i]; ?>" alt="img">
									<img class="c-showSP" src="assets/images/<?php echo $arr_imgsp[$i]; ?>" alt="img">
								</div>
								<h5 class="list2__title1"><?php echo $arr_title[$i]; ?></h5>
							</a>
							<?php endif; endfor; ?>
						</div>
					</div>
				</article>

				<article class="box1">
					<h2 class="c-title1">REGISTER TO VISIT</h2>
					<h2 class="box1-title1">OUR PROJECT</h2>
					
					<div class="box1__text1">
						<div class="list1">
							<p class="list1__item1"><strong>Address: </strong>201 Ngo Chi Quoc street, Vinh Phu village, Thuan An town, Binh Duong province</p>
							<div class="list1-b1">
								<a href="#"><strong>Email: </strong>info@qiisland.vn</a>
								<a href="tel: 0858626368"><strong>Hotline: </strong>0858626368</a>
							</div>
						</div>
					</div>
					<form id="formregister" class="c-form1" method="POST" action="">
						<div class="c-form1__info">
							<!-- <label for="">Họ & tên:</label> -->
							<input id="HoVaTen" name="hovaten" type="text" placeholder="Họ & tên:" required>
						</div>
						<div class="c-form1__info">
							<!-- <label for="">Địa chỉ: </label> -->
							<input id="DiaChi" name="diachi" type="text" placeholder="Địa chỉ: " required>
						</div>
						<div class="c-form1__info">
							<!-- <label for="">Điện thoại:</label> -->
							<input id="DienThoai" name="dienthoai" type="text" placeholder="Điện thoại:">
						</div>
						<div class="c-form1__info">
							<!-- <label for="">Email:</label> -->
							<input id="Email" name="email" type="email" placeholder="Email:">
						</div>
						<button class="btn1" type="submit">REGISTER</button>
					</form>
				</article>
				<!-- <div class="list1">
						<p class="list1__item1">201 Đường Ngô Chí Quốc, Vĩnh Phú, Tx. Thuận An, Bình Dương</p>
						<p class="list1__item1">
								<a href="">info@qiisland.vn</a>
						</p>
				</div> -->
			</section>
			<div class="c-footer__bg1"><img src="assets/images/bg-footer2.jpg" alt="bg-footer1.jpg"></div>
		</section>
		
		<section class="c-footer__content2">
			<div class="container">
				<p class="c-copyright">Copyright © 2019 Qi ISLAND</p>
			</div>
		</section>
	</section>
</section>
</section>
</div>
<script type='text/javascript' src='https://code.jquery.com/jquery-1.11.0.min.js'></script> 
<script type="text/javascript" src="assets/js/jquery.js" ></script>
<script type='text/javascript' src='assets/js/dd-location.js'></script>
<!-- <script type="text/javascript" src="assets/js/jquery.js" ></script> -->
<script type='text/javascript' src='assets/js/fullpage.js'></script>
<script type='text/javascript' src='assets/js/scrolloverflow.min.js'></script>
<!-- <script type='text/javascript' src='assets/js/slick.js'></script> -->
<script type='text/javascript' src='assets/js/owl.carousel.min.js'></script>
<script type='text/javascript' src='assets/js/imagesloaded.pkgd.min.js'></script>
<script type="text/javascript" src="https://masonry.desandro.com/masonry.pkgd.js"></script>
<script type='text/javascript' src='assets/js/jquery.magnific-popup.min.js'></script>

<script type='text/javascript' src='assets/js/script.js'></script>
<script type='text/javascript' src='assets/js/common.js'></script>
<script type='text/javascript' src='assets/js/script_owl.js'></script>
<script>
$ =  jQuery;
function redirectToThankYou(content, success) {
if(success){
$('#result').html('<div id="success-msg" class="alert alert-success"><strong>Success!</strong> Your registration has already been sent successfully</div>');
}
else{
$('#result').html('<div id="error-msg" class="alert alert-danger"><strong>Opp!</strong> Some thing went wrong</div>');
}
}
		//console.log("a");
</script>
<script src='https://mailvas.mangoads.com.vn/client.js?token=$2y$10$3YkYSVZ4OmcYiVJdcHZxGeJ6zzLsLwOokq.az8VRS6SKsk60wijUa&target=formregister&v=1.1&callback=redirectToThankYou' type='application/javascript'></script>
</body></html>
