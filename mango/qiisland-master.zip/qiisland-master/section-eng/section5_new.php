<style>
  .p-top6 {
    background-image: url(assets/images/bg-news-pc.jpg);
  }
  @media only screen and (max-width: 767px) {
    .p-top6 { 
      background-image: <?php echo 'url(assets/images/bg-news.jpg);' ?>;
    }
  }
</style>

<section class="section p-top6 fp-auto-height-responsive___ animate-top6-js sec-gallery ">
	<section class="p-top6__inner1">
		<h2 class="c-title1 a-hiddenTop">GALLERY</h2>
		<div class="container">
			<div class="owl-carousel owl-visible s-loop s-nav s-auto"   paramowl="nav=.custom-nav-gallery||margin=0||autospeed=0">
			<?php 
			for($i=1;$i<=3;$i++){?>
			  <div class="item-visible">
			    <div class="item ">
			      <div class="img tRes_65"><img  src="assets/images/image<?php echo $i; ?>.jpg" alt=""></div>
			    </div>
			  </div>
			<?php
			}?>
			</div>
			<div class="custom-nav-gallery"></div>
		</div>
	</section>

	<div class="p-top6__circle1">
		<img src="assets/images/mask-circle.png" alt="mask-circle.png">
	</div>
</section>
