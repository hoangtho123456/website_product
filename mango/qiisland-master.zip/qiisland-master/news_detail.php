<?php include 'include/index-top-1.php';?>
  
<main class="l-main">
  <section class="p-newsdetail1">
    <div class="p-newsdetail1__bg">
      <img src="assets/images/bg-news-pc.jpg" alt="bg-news-pc.jpg">
    </div>
    <div class="container">
      <h2 class="c-title1 c-title1--type1">Tin tức</h2>
      
      <section class="p-newsdetail1__box1">
        <div class="c-maintitle1">
          <h3 class="c-title2">Bình dương ĐANG TRỞ THÀNH ĐẤT VÀNG</h3>
          <span class="c-date1" href="#">Dec 21, 2019</span>
        </div>

        <section class="content1">
          <div class="img1">
            <img src="assets/images/news/detail1.jpg" alt="detail1.jpg">
          </div>
          
          <article class="content1__child1">
            <p class="bold-text">
              Với lớp cư dân thành đạt và tinh tế, một không gian sống lý tưởng là sự kết hợp hài hòa giữa các yếu tố quan trọng – từ vị trí đắc địa, thiết kế độc đáo, sự riêng tư, cộng đồng tinh hoa và các đặc quyền thượng lưu. Lancaster Eden, dự án biệt thự hạng sang phiên bản giới hạn do Trung Thủy Group phát triển tại khu đô thị An Phú – An Khánh, Quận 2, chính là một không gian lý tưởng như vậy.
            </p>

            <p>
              Tọa lạc ngay mặt tiền đường Trần Lựu, phường An Phú và được bao quanh bởi các tuyến đường huyết mạch như Mai Chí Thọ, Xa lộ Hà Nội, Trần Não, Lương Định Của, Lancaster Eden là khu biệt thự biệt lập duy nhất tại khu đô thị mới An Phú – An Khánh, thu hút sự quan tâm đặc biệt của lớp khách hàng thành đạt và am tường phong cách sống. Từ đây, cư dân có thể kết nối với trung tâm Quận 1 theo nhiều cách – từ tuyến đường Xa lộ Hà Nội qua cầu Sài Gòn hoặc theo tuyến đường Lương Định Của qua Cầu Thủ Thiêm về chợ Bến Thành.
            </p>

            <p>
              Lấy cảm hứng từ khu vườn địa đàng Eden trong truyền thuyết, Lancaster Eden ẩn chứa sự bay bổng mềm mại phía sau mỗi đường nét kiến trúc sắc sảo. Đó là sự kết hợp của cỏ cây hoa lá cùng với các cảnh quan mặt nước, được bố trí khéo léo xuyên suốt mọi ngõ ngách của dự án. Mỗi căn biệt thự đều được thiết kế giật cấp để tối ưu hóa việc nhận ánh sáng, đồng thời xóa nhòa khoảng cách giữa không gian bên trong và bên ngoài. Mọi thiết kế đều được tính toán kỹ lưỡng để chủ nhân có thể dễ dàng tương tác với ánh sáng và thiên nhiên từ nhiều vị trí khác nhau, dù đó là phòng khách sang trọng, phòng ngủ tinh tế, hay gian bếp ấm cúng. Kiểu thiết kế cửa cao 3.1 m cũng là một điểm nhấn làm nên nét đặc biệt cho không gian biệt thự Lancaster Eden.
            </p>

            <p>
              <div class="img1">
                <img src="assets/images/news/detail2.jpg" alt="detail2.jpg">
              </div>
            </p>

            <p>
              Tọa lạc ngay mặt tiền đường Trần Lựu, phường An Phú và được bao quanh bởi các tuyến đường huyết mạch như Mai Chí Thọ, Xa lộ Hà Nội, Trần Não, Lương Định Của, Lancaster Eden là khu biệt thự biệt lập duy nhất tại khu đô thị mới An Phú – An Khánh, thu hút sự quan tâm đặc biệt của lớp khách hàng thành đạt và am tường phong cách sống. Từ đây, cư dân có thể kết nối với trung tâm Quận 1 theo nhiều cách – từ tuyến đường Xa lộ Hà Nội qua cầu Sài Gòn hoặc theo tuyến đường Lương Định Của qua Cầu Thủ Thiêm về chợ Bến Thành.
            </p>
            
            <p>Lấy cảm hứng từ khu vườn địa đàng Eden trong truyền thuyết, Lancaster Eden ẩn chứa sự bay bổng mềm mại phía sau mỗi đường nét kiến trúc sắc sảo. Đó là sự kết hợp của cỏ cây hoa lá cùng với các cảnh quan mặt nước, được bố trí khéo léo xuyên suốt mọi ngõ ngách của dự án. Mỗi căn biệt thự đều được thiết kế giật cấp để tối ưu hóa việc nhận ánh sáng, đồng thời xóa nhòa khoảng cách giữa không gian bên trong và bên ngoài. Mọi thiết kế đều được tính toán kỹ lưỡng để chủ nhân có thể dễ dàng tương tác với ánh sáng và thiên nhiên từ nhiều vị trí khác nhau, dù đó là phòng khách sang trọng, phòng ngủ tinh tế, hay gian bếp ấm cúng. Kiểu thiết kế cửa cao 3.1 m cũng là một điểm nhấn làm nên nét đặc biệt cho không gian biệt thự Lancaster Eden.</p>
          </article>
        </section>
      </section>
    </div>
  </section>

  <section class="p-newsdetail2">
    <div class="container">
      <section class="p-newsdetail2__box1">
        <h2 class="c-title1 c-title1--type1">Tin liên quan</h2>

        <section class="p-newsdetail2__list1 row">
          <?php
          for($i = 0; $i < 4; $i++):
          ?>
          <div class="col-sm-6 col-md-6 list1__card1">
            <a class="list1__content1" href="#">
              <p class="c-date1">27 - 06 - 2018</p>
              <h3 class="list1__title1">Khi vị thế được đo bằng những “giới hạn”</h3>
            </a>
          </div>
          <?php endfor; ?>
        </section>
      </section>
    </div>
  </section>
</main>

<?php include 'include/index-bottom-1.php';?>
