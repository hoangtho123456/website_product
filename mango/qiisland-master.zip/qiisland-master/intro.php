<?php include 'include/index-top-1.php';?>
  
<main class="l-main">
  
  <section data-tooltip="Giới thiệu" class="p-intro1">
    <div class="dd-s-about js-tab">
      <ul class="dd-mini-menu js-tab-menu mobile-hide">
        <li><a href="#" class="active" data-index="0">Giới thiệu dự án</a></li>
        <li><a href="#" data-index="1" class="">Chủ đầu tư và Đối tác</a></li>
      </ul>

      <div class="dd-b-container">
        <div class="dd-tab-container js-tab-container active">
          <div class="p-intro1__slider1 p-intro1__slider1-js">
            <div class="owl-carousel">
              <?php 
                // $arr_title = ['townhouse - middle', 'sHOPHouse - middle',
                // 'sHOPHouse - CORNER']; 
                for($i = 0; $i < 4; $i++): ?>
              <div class="dd-b-about">
                <h2 class="tablet-hide desktop-hide">Tổng quan dự án</h2>
                <div class="dd-photo">
                  <img src="assets/images/intro/slide1.jpg" alt="qiisland">
                </div>
                <div class="dd-info">
                  <p class="mobile-hide">Qi island chính là lựa chọn duy nhất cho những cư dân thông thái mong muốn nâng tầm chất lượng cuộc sống với 3 KẾT NỐI VÀNG: Kết nối địa lý - Kết nối thiên nhiên – Kết nối công nghệ.</p>
                </div>
              </div>
              <?php endfor; ?>
            </div>
          </div>

          <!-- <div class="dd-b-about">
            <h2 class="tablet-hide desktop-hide">Tổng quan dự án</h2>
            <div class="dd-photo">
              <img src="assets/images/intro/slide1.jpg" alt="qiisland">
            </div>
            <div class="dd-info">
              <p class="mobile-hide">Qi island chính là lựa chọn duy nhất cho những cư dân thông thái mong muốn nâng tầm chất lượng cuộc sống với 3 KẾT NỐI VÀNG: Kết nối địa lý - Kết nối thiên nhiên – Kết nối công nghệ.</p>
            </div>
          </div> -->
        </div>

        <div class="dd-tab-container js-tab-container">
          <div class="p-intro1__slider1 p-intro1__slider1-js">
            <div class="owl-carousel">
              <?php 
                // $arr_title = ['townhouse - middle', 'sHOPHouse - middle',
                // 'sHOPHouse - CORNER']; 
                for($i = 0; $i < 4; $i++): ?>
              <div class="dd-b-about">
                <div class="dd-photo">
                  <img src="assets/images/intro/slide1.jpg" alt="qiisland">
                </div>
                <div class="dd-info">
                  <h3 class="dd-info-title1">ĐƠN VỊ HỖ TRỢ VAY VỐN</h3>
                  <p>Qi island chính là lựa chọn duy nhất cho những cư dân thông thái mong muốn nâng tầm chất lượng cuộc sống với 3 KẾT NỐI VÀNG: Kết nối địa lý - Kết nối thiên nhiên – Kết nối công nghệ.</p>
                  <div class="dd-info-img1">
                    <img src="assets/images/logo-Vietbank.png" alt="logo-Vietbank">
                  </div>
                </div>
              </div>
              <?php endfor; ?>
            </div>
          </div>

          <!-- <div class="dd-b-investor">
            <h2 class="tablet-hide desktop-hide">Chủ đầu tư</h2>
            <img src="http://eden.lancaster.com.vn/themes/eden/assets/images/logo-ttg.svg" 
            alt="TTG" class="dd-logo">
            <div class="dd-info">
              <p><strong class="is-large">Trung Thủy Group (TTG Holding) là Tập đoàn đa ngành được thành lập từ năm 1995. Với hoạt động đầu tư và phát triển các dự án căn hộ cao cấp, TTG Holding đang dần trở thành một trong những thương hiệu bất động sản hàng đầu Việt Nam.</strong></p>
              <p>Tiên phong trong những thiết kế độc đáo và thông minh, TTG Holding luôn nỗ lực tạo ra không gian sống đầy tính mỹ thuật và đảm bảo chất lượng, nâng cao cuộc sống con người và duy trì những giá trị bền vững cho thế hệ sau.</p>
              <p>Mọi sản phẩm đều bắt đầu và kết thúc bằng sự hài lòng của chính khách hàng.</p>
            </div>
          </div> -->
        </div>
      </div>
      <!-- <ul class="dd-dot-menu js-tab-menu tablet-hide desktop-hide">
        <li><a href="#" class="active" data-index="0">Tổng quan dự án</a></li>
        <li><a href="#" data-index="1">Chủ đầu tư</a></li>
      </ul> -->
    </div>
  </section>

</main>

<?php include 'include/index-bottom-1.php';?>
