<section class="breadcrumbs">
    <div class="container">
        <a class="item" href="#"> Home /</a> 
        <a class="item" href="#"> Substainability /</a> 
        <span class="item">  Community </span> 
    </div>
</section>
