<section class="breadcrumbs">
    <div class="container">
        <a class="item" href="#"> Home /</a> 
        <a class="item" href="#"> Investors /</a>
        <span class="item">  Annual report </span>
    </div>
</section>
