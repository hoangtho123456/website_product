<section class="breadcrumbs">
    <div class="container">
        <a class="item" href="#"> Home /</a> 
        <a class="item" href="#"> Media /</a>
        <span class="item">  News </span> 
    </div>
</section>
