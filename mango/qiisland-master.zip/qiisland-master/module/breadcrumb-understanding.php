<section class="breadcrumbs">
    <div class="container">
        <a class="item" href="#"> Home /</a> 
        <a class="item" href="#"> Investors /</a>
        <span class="item">  Understanding TH </span> 
    </div>
</section>
