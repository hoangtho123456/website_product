<?php include 'include/index-top-1.php';?>
  
<main class="l-main p-project0">
  <div class="p-project0__bg">
    <img src="assets/images/reversize2/banner1-reversize.jpg" alt="banner1-reversize.jpg">
  </div>

  <section class="p-project1">
    <div class="container">
      <h2 class="c-title4">Khu QI REVESIZE</h2>

      <section class="p-project1__box1">
        <div class="row">
          <div class="col-md-5 col-lg-4">
            <h1 class="p-project1__title1">Bản đồ vị trí</h1>
            
            <div class="c-showSP p-project1__list1 list1__tag1-js">
              <ul class="owl-carousel">
                <?php 
                  $arr_title = ['townhouse - middle', 'sHOPHouse - middle',
                  'sHOPHouse - CORNER']; 
                  for($i = 0; $i < 3; $i++): ?>
                <li class="list1__tag1 btn-js">
                  <a class="__" href="#tab<?php echo $i; ?>">
                    <h3>Căn hộ mẫu</h3>
                    <h3><?php echo $arr_title[$i]; ?></h3>
                  </a>
                </li>
                <?php endfor; ?>
              </ul>
            </div>

            <ul class="c-showPC p-project1__list1 list1__tag1-js">
              <?php 
                $arr_title = ['townhouse - middle', 'sHOPHouse - middle',
                'sHOPHouse - CORNER']; 
                for($i = 0; $i < 3; $i++): ?>
              <li class="list1__tag1 btn-js">
                <a class="__" href="#tab<?php echo $i; ?>">
                  <h3>Căn hộ mẫu</h3>
                  <h3><?php echo $arr_title[$i]; ?></h3>
                </a>
              </li>
              <?php endfor; ?>
            </ul>
          </div>

          <div class="col-md-7 col-lg-8 tabs-js">
            <?php 
              $arr_img1 = ['pj1.png']; 
              for($i = 0; $i < 3; $i++): ?>
            <div id="tab<?php echo $i; ?>" class="p-project1__img1 tab-js">
              <a href="https://qiisland.vn/reversize.php">
                <img src="assets/images/reversize2/<?php echo $arr_img1[0]; ?>" alt="img">
              </a>
            </div>
            <?php endfor; ?>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>

<?php include 'include/index-bottom-1.php';?>
