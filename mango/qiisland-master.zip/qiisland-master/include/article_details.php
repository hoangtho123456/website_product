 <article class="article-details">
    <h4 class="cl1"> TH Group is proud to officially receive the symbol of "National Brand" </h4>
    <span class="c-date1">June 26th 2019</span>


    <div class="entry-content">
 <p >National Brand is the only program of the Government of Vietnam to promote the image and National Brand through brand products, goods and services; The main goal is to build the image of Vietnam in association with the values of "Quality - Innovation, Innovation - Pioneering capacity".</p>

<p >According to Decision No. 4669 / QD-BCT dated 18/12/2018 of the Minister of Industry and Trade - Chairman of the National Brand Council, TH Milk Joint Stock Company has been recognized by the National Brand Council as an enterprise. Branded products reach National Brand in 2018 and are entitled to the Program's logo in two years from 2018 to 2020.</p>

<p ><img alt="" src="http://www.thmilk.vn/image/data/tin-tuc/1 A Hai nhan giai OK.jpg"></p>

<p ><em>Representatives of TH Group were honored to receive the symbol "National Brand" from Deputy Prime Minister Trinh Dinh Dung and Minister of Industry and Trade Tran Tuan Anh</em></p>

<p >This is the third time TH has been honored and proud to be recognized as "National Brand", and was honored with five product groups: Fresh milk TH True MILK, TOPKID formulas, Fresh fresh milk study TH SCHOOL MILK; True YOGURT TH yogurt and sterilized drinking yogurt TH TOPTEEN.</p>

<p >National Brand (Vietnam Value) is a program assigned by the Prime Minister to the Ministry of Industry and Trade (Trade Promotion Agency is a standing agency) in coordination with other Ministries / Agencies to implement since 2003.</p>

<p >This is the only program of the Government of Vietnam to promote national image and brand through product brand (goods and services); The main goal is to build the image of Vietnam in association with the values ​​of "Quality - Innovation, Innovation - Pioneering capacity"; adding prestige, pride and attractiveness to the country and people of Vietnam, contributing to encouraging tourism and attracting foreign investment.</p>

<p >In 2018, TH is one of the few businesses in the field of food and beverage reaching the National Brand this time.</p>

<p><img alt="" src="http://www.thmilk.vn/image/data/tin-tuc/1 Untitled.png"></p>


<p ><em>After 10 years of launching the first product, more than 70 types of TH products have been received and trusted by consumers. TH is one of the few companies in the food and beverage industry in particular with products reaching "National Brand" 2018</em></p>

<p >Mr. Ngo Minh Hai, Chairman of TH Group shared: “As the third time to achieve this noble title, we understand that consumers have given themselves honor and also a great responsibility for TH group. Therefore, we must always strive to maintain the title and increase product value, bringing true values ​​to the society. ”</p>

<p >To achieve the National Brand, products - services must meet strict criteria such as being produced and supplied by advanced technology, environmentally friendly, using domestic materials, capable of exporting. import and replace imported products; occupy a large proportion in the domestic market and in export turnover, selected by consumers ..</p>

<p >TH Group has consistently achieved the National Brand since 2012, and is taking steady steps in the country, expanding investment in dairy breeding and processing projects in Thanh Hoa, Ha Giang and Phu Yen. . In addition to dairy products, TH has continuously developed new products for public health such as TH true HERBAL herbal drink, TH true NUT premium milk, fermented drinking water from TH true MALT barley sprouts. , pure water TH true WATER. Besides, TH has promoted investment in international markets, notably the high-tech Dairy Processing and Dairy Complex Project in Russia with a total capital of up to 2.7 billion USD. TH is also promoting products to be available in fastidious markets but with potential such as the US, China and ASEAN regions.</p>



    </div>
 
</article>