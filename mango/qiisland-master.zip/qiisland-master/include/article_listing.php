 <article>
    <figure>
        <a href="06_details.php">
            <img  src="assets/images/h-<?php echo $i; ?>.jpg">
        </a>
    </figure>
    <h4 class="article-title text-uppercase color-primary">
        <a href="06_details.php">
        <?php echo $ss1_title;?>
        </a>
    </h4>
    <div class="article-desc">
        <?php echo $ss1_desc;?>
    </div>
    <a class="btn btn" href="06_details.php">See more</a>
</article>