<div class="widget widget-menu">
  <ul class="menu">
    <li class="active"><a href="03_founder.php">Founder</a></li>
    <li><a href="04_vision.php">Vision & mission</a></li>
    <li><a href="06_leadership.php">Leadership</a></li>
    <li><a href="#">Management</a></li>
    <li><a href="#">Business principles</a></li>
    <li><a href="05_investor.php">Innovation</a></li>
    <li><a href="09_awards.php">Awards</a></li>
    <li><a href="10_milestones.php">Milestones</a></li>
   </ul>
</div>

    















