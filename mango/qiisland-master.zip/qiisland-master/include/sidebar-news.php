<div class="widget widget-menu">
  <ul class="menu">
    <li class="active"><a href="03_founder.php">News</a></li>
    <li><a href="04_vision.php">Press release</a></li>
    <li><a href="#">Photo gallery</a></li>
    <li><a href="#">Video Library</a></li>
    <li><a href="#">Media contact</a></li>
  </ul>
</div>
