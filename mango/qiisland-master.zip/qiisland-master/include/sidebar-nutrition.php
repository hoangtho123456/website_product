<div class="widget widget-menu">
  <ul class="menu">
    <li class="active"><a href="./14_nutrition&heart.php">Nutrition & Healthy</a></li>
    <li><a href="./14_environment.php">Environment</a></li>
    <li><a href="./14_substainability_people.php">People</a></li>
    <li><a href="#">Education</a></li>
    <li><a href="./14_substainability_community.php">Community</a></li>
    <li><a href="./14_substainability_bonds.php">Bonds of life</a></li>
   </ul>
</div>

    















