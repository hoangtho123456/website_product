<li id="li1"><a href="./01_index.php">Sản phẩm cao cấp</a></li>
<li id="li2"><a href="./03_founder.php">Phụ kiện Cao cấp</a></li>
<li id="li3"><a href="./12_our_brands.php">Quà tặng</a></li>
<li id="li4"><a href="./12_our_brands.php">Tin tức</a></li>
<li id="li5"><a href="./12_our_brands.php">Liên hệ</a></li>

<!-- <li class="children"  id="li4"><a href="./14_substainability.php">CỬA HÀNG</a>
  <ul>
    <li><a href="./15_our_project.php">Our Projects</a></li>
    <li><a href="./16_quater_report.php">Quarter Report</a></li>
    <li><a href="./17_foundation.php">Foundation</a></li>
  </ul>
</li> -->
