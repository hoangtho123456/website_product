<?php include 'include/index-top-1.php';?>
  
<main class="l-main">
  <section class="p-images1">
    <div class="p-news1__bg">
      <img src="assets/images/bg-news-pc.jpg" alt="bg-news-pc.jpg">
    </div>
    <div class="container">
      <h2 class="c-title1 c-title1--type1">Hình ảnh</h2>
      
      <div class="p-images1__list1">
        <section class="c-rowlist1 row">
          <?php
            $arr = ['pj1.jpg', 'pj2.jpg', 'pj3.jpg',
            'pj4.jpg', 'pj5.jpg', 'pj6.jpg',
            'pj7.jpg', 'pj8.jpg', 'pj9.jpg'];
            for($i = 0; $i < 9; $i++):
          ?>
          <div class="col-sm-6 col-md-6 col-lg-4 list1__card1">
            <a class="list1__content1 p-img1-js" href="assets/images/news/<?php echo $arr[$i];?>">
              <div class="list1__img1">
                <img src="assets/images/news/<?php echo $arr[$i];?>" alt="img1.png">
              </div>
            </a>
          </div>
          <?php endfor; ?>
        </section>
      </div>
      <div class="p-images1__btn1">
        <a href="#" class="c-btn1">Xem thêm</a>
      </div>
    </div>
  </section>
</main>

<?php include 'include/index-bottom-1.php';?>
