<?php include 'include/index-top.php';?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Multi Slide</title>
<link rel="shortcut icon" href="images/favicon.ico">
<link rel='stylesheet'  href='https://kenwheeler.github.io/slick/slick/slick.css' type='text/css' media='all' />
<link rel='stylesheet'  href='css/main.css' type='text/css' media='all' />




</head>

<body>
<section class="wrap-multi-slide">
  <div class="container" >
    <div class="group-slide">

      <div class="slick-slide-2">
        <?php for($i=1;$i<=5;$i++){ ?>
        <div class="item ">
          <div class="img"><img src="<?php echo $i; ?>.jpg" /></div>
        </div>
        <?php } ?>
      </div>      
      <div class="slick-slide-3">
        <?php for($i=1;$i<=5;$i++){ ?>
        <div class="item ">
          <div class="img"><img src="<?php echo $i; ?>.jpg" /></div>
        </div>
        <?php } ?>
      </div>   
      <div class="slick-slide-4">
        <?php for($i=1;$i<=5;$i++){ ?>
        <div class="item ">
          <div class="img"><img src="<?php echo $i; ?>.jpg" /></div>
        </div>
        <?php } ?>
      </div>         
    </div>
  </div>

    <div class="slick-slide-1">
      <?php for($i=1;$i<=5;$i++){ ?>
      <div class="item">  
        <div class="container" >
          <div class="desc">
            <h1><?php echo $i; ?></h1>
            <p>Qi island là sự kết hợp hài hòa giữa kiến trúc hiện đại & sắc xanh tươi sáng của miền thiên nhiên thuần khiết, cùng dòng nước mát lành bao quanh.</p>
            <p>Qi island là sự trở về với ngôi nhà ấm áp, ngập tràn yêu thương trong không gian sống thông minh, tiện nghi & đẳng cấp.</p>

          </div>
        </div>  
      </div>
      <?php } ?>
    </div>

</section>



<script type='text/javascript' src='https://code.jquery.com/jquery-1.11.0.min.js'></script> 
<script type='text/javascript' src='https://kenwheeler.github.io/slick/slick/slick.js'></script> 


<script type="text/javascript">
// JavaScript Document
(function($){
    $(document).ready(function(){

        const $slider = $(".slick-slide-1");
        const $slider2 = $(".slick-slide-2");
        const $slider3 = $(".slick-slide-3");
        const $slider4 = $(".slick-slide-4");
        $slider.on('init', () => {
            mouseWheel($slider)
        }).slick({
            dots: false,
            fade: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,     
            asNavFor: '.slick-slide-2,.slick-slide-3,.slick-slide-4',       
        })


        $slider2.on('init', () => {
            mouseWheel($slider2)
        }).slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,    
            asNavFor: '.slick-slide-1',       
        })  
        $slider3.on('init', () => {
            mouseWheel($slider3)
        }).slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,   
            asNavFor: '.slick-slide-1',       
        })  
        $slider4.on('init', () => {
            mouseWheel($slider4)
        }).slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1, 
            asNavFor: '.slick-slide-1',      
        })  


        function mouseWheel($slider) {
          $(window).on('wheel', { $slider: $slider }, mouseWheelHandler)
        }
        function mouseWheelHandler(event) {
          event.preventDefault()
          const $slider = event.data.$slider
          const delta = event.originalEvent.deltaY
          if(delta > 0) {
            $slider.slick('slickPrev')
          }
          else {
            $slider.slick('slickNext')
          }
        }



    }); 

})(jQuery); 
    
</script>



</body></html>

