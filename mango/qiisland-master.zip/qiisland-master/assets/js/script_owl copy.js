(function ($) {
    $(document).ready(function () {
        function itemOwl(owl,responsive,margin,autospeed,dataout,datain) {
            owl.owlCarousel({
                navText: ["<i class='icon-arrow-1'></i>","<i class='icon-arrow-2'></i>"],
                nav:(owl.hasClass('s-nav') ? true : false),
                dots:(owl.hasClass('s-dots') ? true : false),
                loop: owl.hasClass('s-loop') ? true : false,
                autoplay: owl.hasClass('s-auto') ? true : false,
                autoplayHoverPause:true,
                center: owl.hasClass('s-center') ? true : false,
                autoWidth: (owl.hasClass('s-width') ? true : false),
                autoHeight: (owl.hasClass('s-height') ? true : false),
                lazyLoad:(owl.hasClass('s-lazy') ? true : false),
                video:(owl.hasClass('s-video') ? true : false),
                autoplayTimeout: (autospeed ? parseInt(autospeed) : 5000),                
                animateOut: dataout,
                animateIn: datain,       
                responsive:{
                    0:{
                        margin: parseInt(margin[4]),
                        items:parseInt(responsive[4]),
                    },
                    480:{
                        margin: parseInt(margin[3]),
                        items:parseInt(responsive[3]),
                    },
                    768:{
                        margin: parseInt(margin[2]),
                        items:parseInt(responsive[2]),
                    },
                    992:{
                        margin: parseInt(margin[1]),
                        items:parseInt(responsive[1]),
                    },
                    1200:{
                        margin: parseInt(margin[0]),
                        items:parseInt(responsive[0]),
                    }
                }
            })            
        }
        // Responsive OWL    
        function ResOwlSlider() {
            $(".owl-carousel").each(function () {
                var owl = $(this),
                    responsive =  owl.attr('data-res'),
                    margin =  owl.attr('data-margin'),  
                    autospeed = owl.attr('data-autospeed'), 
                    dataout = owl.attr('data-out'),
                    datain = owl.attr('data-in'); 
                if(!responsive) { responsive = '1,1,1,1,1'; }
                responsive = responsive.split(',');
                if(!margin) { margin = '0,0,0,0,0'; }
                margin = margin.split(',');

                owl.imagesLoaded(function(){    
                    itemOwl(owl,responsive,margin,autospeed,dataout,datain);
                });
            });    
        }        
        ResOwlSlider();    


        // Responsive OWL    
        function SynOwlSlider() {
            $(".wrap-syn-owl").each(function () {
                var $this = $(this);
                var sync1 = $this.find(".syn-slider-1");
                var sync2 = $this.find(".syn-slider-2");

                // var autospeed1 = sync1.attr('data-autospeed'); 
                // var dataout1 = sync1.attr('data-out'); 
                // var datain1 = sync1.attr('data-in');     
                // var margin1 = ['0','0','0','0','0'];
                // var responsive1 = ['1','1','1','1','1'];

                var responsive1 =  sync1.attr('data-res'),
                    margin1 =  sync1.attr('data-margin'),  
                    autospeed1 = sync1.attr('data-autospeed'), 
                    dataout1 = sync1.attr('data-out'),
                    datain1 = sync1.attr('data-in'); 
                if(!responsive1) { responsive1 = '1,1,1,1,1'; }
                responsive1 = responsive1.split(',');
                if(!margin1) { margin1 = '0,0,0,0,0'; }
                margin1 = margin1.split(',');


                var responsive2 =  sync2.attr('data-res'),
                    margin2 =  sync2.attr('data-margin'),  
                    autospeed2 = sync2.attr('data-autospeed'), 
                    dataout2 = sync2.attr('data-out'),
                    datain2 = sync2.attr('data-in'); 
                if(!responsive2) { responsive2 = '1,1,1,1,1'; }
                responsive2 = responsive2.split(',');
                if(!margin2) { margin2 = '0,0,0,0,0'; }
                margin2 = margin2.split(',');



                // var autospeed2 = sync2.attr('data-autospeed'); 
                var responsive =  sync2.attr('data-res').split(',');
                var margin =  sync2.attr('data-margin').split(',');  




                var slidesPerPage = 5; //globaly define number of elements per page
                var syncedSecondary = true;

                  itemOwl(sync1,responsive1,margin1,autospeed1,dataout1,datain1);
                  sync1.on('changed.owl.carousel', syncPosition);

                  sync2
                    .on('initialized.owl.carousel', function () {
                      sync2.find(".owl-item").eq(0).addClass("current");
                    });

                    sync2.owlCarousel({
                        smartSpeed: 200,
                        slideSpeed : 500,
                        //slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
                        //responsiveRefreshRate : 100,
                        navText: ["<i class='icon-3'></i>","<i class='icon-4'></i>"],
                        nav:(sync2.hasClass('s-nav') ? true : false),
                        dots:(sync2.hasClass('s-dots') ? true : false),
                        autoWidth: (sync2.hasClass('s-width') ? true : false),
                        autoHeight: (sync2.hasClass('s-height') ? true : false),
                        lazyLoad:(sync2.hasClass('s-lazy') ? true : false),
                        responsive:{
                            0:{
                                margin: parseInt(margin[4]),
                                items:parseInt(responsive[4])
                            },
                            480:{
                                margin: parseInt(margin[3]),
                                items:parseInt(responsive[3])
                            },
                            768:{
                                margin: parseInt(margin[2]),
                                items:parseInt(responsive[2])
                            },
                            992:{
                                margin: parseInt(margin[1]),
                                items:parseInt(responsive[1])
                            },
                            1200:{
                                margin: parseInt(margin[0]),
                                items:parseInt(responsive[0])
                            }

                        }

                  });

                    //itemOwl(sync2,responsive2,margin2,autospeed2,dataout2,datain2);



                    sync2.on('changed.owl.carousel', syncPosition2);

                  function syncPosition(el) {
                    //if you set loop to false, you have to restore this next line
                    //var current = el.item.index;
                    
                    //if you disable loop you have to comment this block
                    var count = el.item.count-1;
                    var current = Math.round(el.item.index - (el.item.count/2) - .5);
                    
                    if(current < 0) {
                      current = count;
                    }
                    if(current > count) {
                      current = 0;
                    }
                    
                    //end block

                    sync2
                      .find(".owl-item")
                      .removeClass("current")
                      .eq(current)
                      .addClass("current");
                    var onscreen = sync2.find('.owl-item.active').length - 1;
                    var start = sync2.find('.owl-item.active').first().index();
                    var end = sync2.find('.owl-item.active').last().index();
                    
                    if (current > end) {
                      sync2.data('owl.carousel').to(current, 100, true);
                    }
                    if (current < start) {
                      sync2.data('owl.carousel').to(current - onscreen, 100, true);
                    }
                  }
                  
                  function syncPosition2(el) {
                    if(syncedSecondary) {
                      var number = el.item.index;
                      sync1.data('owl.carousel').to(number, 100, true);
                    }
                  }
                  
                  sync2.on("click", ".owl-item", function(e){
                    e.preventDefault();
                    var number = $(this).index();
                    sync1.data('owl.carousel').to(number, 300, true);
                  });
            });    
        }        
        SynOwlSlider();    
    });
})(jQuery); 