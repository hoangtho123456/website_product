
(function($) {
    $(document).ready(function () {
        var $window = $(window);
        var body = $('body');
        SpinCircleStart();        // amenitites
        ClickIcon();        // nt
        var homeInit = new HomeInit();
        homeInit.ClickListIcon();
    });
    //end document ready
    function HomeInit() { //some function for homepage
        var win = $(window);
        this.ClickListIcon = function () {
            var imgPlaceHolder = $('#ulilities-bg-placeholder');
            var deg = 0;
            var getImgSrc;
            getImgSrc = $('.utilities-list-item li a').eq(2).data('img');
            imgPlaceHolder.attr('src',getImgSrc);
            $('.utilities-list-item li a').on('click',function (e) {
                e.preventDefault();
                var id = this.id;
                var num = id.substring(8, 10);
                getImgSrc = $(this).data('img');
                $('.utiliti-content-wrap').removeClass('utiliti-content-active');
                $('#utiliti-content-'+num).addClass('utiliti-content-active');
                
                //imgPlaceHolder.parent('.ulilities-bg').fadeOut(100);
                imgPlaceHolder.attr('src',getImgSrc);
                //imgPlaceHolder.parent('.ulilities-bg').fadeIn(300);
                //console.log('sfsdfd');
            });
        };

        // PointClick();
        $('.icon-utilitis-wrap a').on('click', function () {
            $('.icon-utilitis-wrap a').removeClass('active');
            $(this).addClass('active');
        });
    }// End homepagejs

    // amenities Function
    function SpinCircleStart() {
        //var deg = 22.5; //default variable

        var deg = 76.5;
        //var deg = -99.5;

        
        var degArr = [];
        for(var i = 1; i <= 12; i++){
            // degArr = degArr.push(deg);
            $('.utilities-list-item ul li:nth-child('+i.toString()+')').css({
                '-webkit-transform': 'translate(-50%,-50%) rotate('+deg+'deg)',
                '-moz-transform': 'translate(-50%,-50%) rotate('+deg+'deg)',
                '-ms-transform': 'translate(-50%,-50%) rotate('+deg+'deg)',
                '-o-transform': 'translate(-50%,-50%) rotate('+deg+'deg)',
                'transform': 'translate(-50%,-50%) rotate('+deg+'deg)'
            });
            // $('.utilities-list-item ul li:nth-child('+i.toString()+') img').css({
            //   '-webkit-transform': ' rotate('+-deg+'deg)',
            //   '-moz-transform': ' rotate('+-deg+'deg)',
            //   '-ms-transform': ' rotate('+-deg+'deg)',
            //   '-o-transform': ' rotate('+-deg+'deg)',
            //   'transform': ' rotate('+-deg+'deg)'
            // });

            $('.utilities-list-item ul li:nth-child('+i.toString()+') img').css({
              '-webkit-transform': ' rotate('+-deg+'deg)',
              '-moz-transform': ' rotate('+-deg+'deg)',
              '-ms-transform': ' rotate('+-deg+'deg)',
              '-o-transform': ' rotate('+-deg+'deg)',
              'transform': ' rotate('+-deg+'deg)'
            });
            //deg += 22.5;
            deg += 35.5;
            //deg += 40.5;
        }
        // console.log(degArr);
    }

    function ClickIcon() {
        $('#list-icon-utilitis li').click(function(i){
            var index = $('#list-icon-utilitis li').index(this) + 1;
            $(this).parent().find('li').last().prependTo( "#list-icon-utilitis ul" );
            var degSpinLargeCircle = 22.5;
            var degAfterSpin = 0;
            console.log(index);
            /*---------------------------*/
            switch (parseInt(index)){
                case 1 : {
                    $(this).parent().find('li:nth-child(4)').prependTo( "#list-icon-utilitis ul" );
                    //$(this).parent().find('li:nth-child(4)').prependTo( "#list-icon-utilitis ul" );
                    //$(this).parent().find('li:nth-child(4)').prependTo( "#list-icon-utilitis ul" );
                    //$(this).parent().find('li:nth-child(4)').prependTo( "#list-icon-utilitis ul" );
                    // $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );


                    // $(this).parent().find('li:nth-child(5)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-90deg)'
                    // });
                    // $(this).parent().find('li:nth-child(4)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-67.5deg)'
                    // });
                    // $(this).parent().find('li:nth-child(3)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-45deg)'
                    // });
                    // $(this).parent().find('li:nth-child(2)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
                    // });
                    $(this).parent().find('li:nth-child(1)').css({
                        'transform': 'translate(-50%, -50%) rotate(0deg)'
                    });

                    setTimeout(function(){
                      SpinCircleStart();
                    },100);
                    break;
                }
                // case 2 : {
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );


                //     $(this).parent().find('li:nth-child(1)').css({
                //         'transform': 'translate(-50%, -50%) rotate(-67.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(2)').css({
                //         'transform': 'translate(-50%, -50%) rotate(-45deg)'
                //     });
                //     $(this).parent().find('li:nth-child(3)').css({
                //         'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(4)').css({
                //         'transform': 'translate(-50%, -50%) rotate(0deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);

                //     break;
                // }
                case 3 : {
                    // $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                    // $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                    // $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                    // $(this).parent().find('li:nth-child(1)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-45deg)'
                    // });
                    // $(this).parent().find('li:nth-child(2)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
                    // });
                    // $(this).parent().find('li:nth-child(3)').css({
                    //     'transform': 'translate(-50%, -50%) rotate(0deg)'
                    // });
                    // setTimeout(function(){
                    // //    SpinCircleStart();
                    // },100);
                    break;
                }
                // case 4 : {

                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );

                //     $(this).parent().find('li:nth-child(2)').css({
                //         'transform': 'translate(-50%, -50%) rotate(0deg)'
                //     });
                //     $(this).parent().find('li:nth-child(1)').css({
                //         'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                // case 5 : {
                //     $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').css({
                //         'transform': 'translate(-50%, -50%) rotate(0deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);

                //     break;
                // }

                // case 6 : {
                //     break;
                // }
                // case 7 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                // case 8 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(11)').css({
                //         'transform': 'translate(-50%, -50%) rotate(315deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                // case 9 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(11)').css({
                //         'transform': 'translate(-50%, -50%) rotate(315deg)'
                //     });
                //     $(this).parent().find('li:nth-child(10)').css({
                //         'transform': 'translate(-50%, -50%) rotate(337.5deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                // case 10 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(11)').css({
                //         'transform': 'translate(-50%, -50%) rotate(315deg)'
                //     });
                //     $(this).parent().find('li:nth-child(10)').css({
                //         'transform': 'translate(-50%, -50%) rotate(337.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(9)').css({
                //         'transform': 'translate(-50%, -50%) rotate(360deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);

                //     break;
                // }
                // case 11 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(11)').css({
                //         'transform': 'translate(-50%, -50%) rotate(315deg)'
                //     });
                //     $(this).parent().find('li:nth-child(10)').css({
                //         'transform': 'translate(-50%, -50%) rotate(337.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(9)').css({
                //         'transform': 'translate(-50%, -50%) rotate(360deg)'
                //     });
                //     $(this).parent().find('li:nth-child(8)').css({
                //         'transform': 'translate(-50%, -50%) rotate(382.5deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                // case 12 : {
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
                //     $(this).parent().find('li:nth-child(12)').css({
                //         'transform': 'translate(-50%, -50%) rotate(292.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(11)').css({
                //         'transform': 'translate(-50%, -50%) rotate(315deg)'
                //     });
                //     $(this).parent().find('li:nth-child(10)').css({
                //         'transform': 'translate(-50%, -50%) rotate(337.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(9)').css({
                //         'transform': 'translate(-50%, -50%) rotate(360deg)'
                //     });
                //     $(this).parent().find('li:nth-child(8)').css({
                //         'transform': 'translate(-50%, -50%) rotate(382.5deg)'
                //     });
                //     $(this).parent().find('li:nth-child(8)').css({
                //         'transform': 'translate(-50%, -50%) rotate(405deg)'
                //     });
                //     setTimeout(function(){
                //     //    SpinCircleStart();
                //     },100);
                //     break;
                // }
                default: { break; }
            }

            // switch (parseInt(index)){
            //     case 1 : {
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );


            //         $(this).parent().find('li:nth-child(5)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-90deg)'
            //         });
            //         $(this).parent().find('li:nth-child(4)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-67.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(3)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-45deg)'
            //         });
            //         $(this).parent().find('li:nth-child(2)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(1)').css({
            //             'transform': 'translate(-50%, -50%) rotate(0deg)'
            //         });

            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 2 : {
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );


            //         $(this).parent().find('li:nth-child(1)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-67.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(2)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-45deg)'
            //         });
            //         $(this).parent().find('li:nth-child(3)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(4)').css({
            //             'transform': 'translate(-50%, -50%) rotate(0deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);

            //         break;
            //     }
            //     case 3 : {
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );


            //         $(this).parent().find('li:nth-child(1)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-45deg)'
            //         });
            //         $(this).parent().find('li:nth-child(2)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(3)').css({
            //             'transform': 'translate(-50%, -50%) rotate(0deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);

            //         break;
            //     }
            //     case 4 : {

            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );

            //         $(this).parent().find('li:nth-child(2)').css({
            //             'transform': 'translate(-50%, -50%) rotate(0deg)'
            //         });
            //         $(this).parent().find('li:nth-child(1)').css({
            //             'transform': 'translate(-50%, -50%) rotate(-22.5deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 5 : {
            //         $(this).parent().find('li:nth-child(12)').prependTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').css({
            //             'transform': 'translate(-50%, -50%) rotate(0deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);

            //         break;
            //     }

            //     case 6 : {
            //         break;
            //     }
            //     case 7 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 8 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(11)').css({
            //             'transform': 'translate(-50%, -50%) rotate(315deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 9 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(11)').css({
            //             'transform': 'translate(-50%, -50%) rotate(315deg)'
            //         });
            //         $(this).parent().find('li:nth-child(10)').css({
            //             'transform': 'translate(-50%, -50%) rotate(337.5deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 10 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(11)').css({
            //             'transform': 'translate(-50%, -50%) rotate(315deg)'
            //         });
            //         $(this).parent().find('li:nth-child(10)').css({
            //             'transform': 'translate(-50%, -50%) rotate(337.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(9)').css({
            //             'transform': 'translate(-50%, -50%) rotate(360deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);

            //         break;
            //     }
            //     case 11 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(11)').css({
            //             'transform': 'translate(-50%, -50%) rotate(315deg)'
            //         });
            //         $(this).parent().find('li:nth-child(10)').css({
            //             'transform': 'translate(-50%, -50%) rotate(337.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(9)').css({
            //             'transform': 'translate(-50%, -50%) rotate(360deg)'
            //         });
            //         $(this).parent().find('li:nth-child(8)').css({
            //             'transform': 'translate(-50%, -50%) rotate(382.5deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);
            //         break;
            //     }
            //     case 12 : {
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(1)').appendTo( "#list-icon-utilitis ul" );
            //         $(this).parent().find('li:nth-child(12)').css({
            //             'transform': 'translate(-50%, -50%) rotate(292.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(11)').css({
            //             'transform': 'translate(-50%, -50%) rotate(315deg)'
            //         });
            //         $(this).parent().find('li:nth-child(10)').css({
            //             'transform': 'translate(-50%, -50%) rotate(337.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(9)').css({
            //             'transform': 'translate(-50%, -50%) rotate(360deg)'
            //         });
            //         $(this).parent().find('li:nth-child(8)').css({
            //             'transform': 'translate(-50%, -50%) rotate(382.5deg)'
            //         });
            //         $(this).parent().find('li:nth-child(8)').css({
            //             'transform': 'translate(-50%, -50%) rotate(405deg)'
            //         });
            //         setTimeout(function(){
            //         //    SpinCircleStart();
            //         },100);

            //         break;
            //     }
            //     default: {
            //         break;

            //     }
            // }
            /*---------------------------*/
        });
    }
    // end amenities function
})(jQuery);

