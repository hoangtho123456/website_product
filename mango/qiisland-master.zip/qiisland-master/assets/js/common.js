/*=================================================*/
jQuery(document).ready(function($) {
  /*---------------------------------------------------
  @tab for page reversize-project
  ---------------------------------------------------*/
  (function tab() {
    $('.tabs-js .tab-js').hide();
    $('.tabs-js .tab-js:first').show();
    $('.list1__tag1-js .btn-js:first-child a').addClass('current');

    $('.list1__tag1-js .btn-js a').click(function(event) {
      event.preventDefault();

      $(".list1__tag1-js .btn-js a").removeClass('current');
      $(this).addClass('current');
      $('.tabs-js .tab-js').hide();

      //store tab's id of a link that was clicked
      var selectTab = $(this).attr("href");

      //show tab corresponding which the 
      //link's href that is clicked 
      $(selectTab).fadeIn();
    });
  }());
  
  /**---------------------------------
  *action: layout when page loading 
  ----------------------------------*/
  // $(window).on('load', function () {
  //   var load_screen = $('.c-load_screen');
  //   load_screen.fadeOut(500); 
  // });
  /*=================================================*/
  // $(window).on('load', function () {
  //   var flashscreen = $('.loading-wrap');
  //   setTimeout(function(){
  //     flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
  //       $(this).remove();
  //       //$('header').addClass('header-active');
  //     });
  //   },1000);
  // });

  // window.onload  = function () {
  //   var flashscreen = $('.loading-wrap');
  //   setTimeout(function(){
  //     flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
  //       $(this).remove();
  //       //$('header').addClass('header-active');
  //     });
  //   },1000)};

  function testLoad() {
    var flashscreen = $('.loading-wrap');
    setTimeout(function(){
    flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
      $(this).remove();
      //$('header').addClass('header-active');
    });
    },1000);
  }

  window.addEventListener("pageshow",
    function () {
        var flashscreen = $('.loading-wrap');
        setTimeout(function(){
        flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
          $(this).remove();
          //$('header').addClass('header-active');
        });
        },1000)}
  , false);

  if (window.attachEvent) {
    window.attachEvent('onload', 
      function () {
        var flashscreen = $('.loading-wrap');
        setTimeout(function(){
        flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
          $(this).remove();
          //$('header').addClass('header-active');
        });
        },1000)});
  }
  else if (window.addEventListener) {window.addEventListener('load', 
    function () {
    var flashscreen = $('.loading-wrap');
    setTimeout(function(){
      flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
        $(this).remove();
        //$('header').addClass('header-active');
      });
    },1000)}
  , false);}
  else {document.addEventListener('load', 
    function () {
    var flashscreen = $('.loading-wrap');
    setTimeout(function(){
      flashscreen.addClass('loading-fade-out').fadeOut(1000, function(){
        $(this).remove();
        //$('header').addClass('header-active');
      });
    },1000)}
  , false);}
  /*=================================================*/

  /*=================================================*/
  /*----USE FOR SECTION UTILITIES PAGE INDEX----*/
  $(".top3-list1-js .owl-carousel").owlCarousel({
    items : 1,
    autoWidth: false,
    nav: false,
    margin: 0,
    dots: true,
    loop: true
  });
  /*=================================================*/
  /*----USE FOR SLIDER PAGE Reversize-ct----*/
  $('.c-slider2-js .owl-carousel').owlCarousel({
    loop: true,
    autoWidth: false,
    margin: 0,
    items: 1,
    nav: true,
    dots: false,
    lazyLoad:true,
    // navContainerClass: 'c-slider1__control1',
    navText: ['', ''],
    navClass: ['c-arrow1 c-arrow1-prev1','c-arrow1 c-arrow1-next1'],
    responsive: {}
  });
  /*=================================================*/
  /*----USE FOR SLIDER PAGE INTRO----*/
  $('.p-intro1__slider1-js .owl-carousel').owlCarousel({
    loop: true,
    autoWidth: false,
    margin: 0,
    items: 1,
    nav: false,
    dots: true,
    lazyLoad:true,
    // navContainerClass: 'c-slider1__control1',
    //navText: ['', ''],
    //navClass: ['c-arrow1 c-arrow1-prev2','c-arrow1 c-arrow1-next2'],
    responsive: {}
  });
  /*=================================================*/
  $(".f-list2-js .owl-carousel").owlCarousel({
    items : 4,
    autoWidth: false,
    nav: false,
    // margin: 20,
    dots: false,
    loop: false,
    responsive: {
      320: {
        items: 2,
        // margin: 20,
      },
      568: {
        items: 3,
        margin: 20,
      },
      768: {
        items: 3,
        margin: 20
      },
      992: {
        items: 3,
        margin: 20
      },
      1200: {
        items: 4,
        margin: 30
      }
    }
  });
  /*=================================================*/
  /*----USE FOR LIST project SP PAGE REVERSIZE-PROJECT----*/
  $('.list1__tag1-js .owl-carousel').owlCarousel({
    loop: false,
    autoWidth: false,
    margin: 10,
    items: 3,
    nav: true,
    dots: false,
    lazyLoad:true,
    // navContainerClass: 'c-slider1__control1',
    navText: ['', ''],
    navClass: ['c-arrow1 c-arrow1-prev2','c-arrow1 c-arrow1-next2'],
    responsive: {}
  });
  /*=================================================*/
  /**---------------------------------
  *action: show popup img page reversize, index
  ----------------------------------*/
  $('.p-img1-js').magnificPopup({
    type: "image",
    image: {
      markup: '<div class="mfp-figure">'+
      '<div class="mfp-close"></div>'+
      '<div class="mfp-img"></div>'+
      '<div class="mfp-bottom-bar">'+
        '<div class="mfp-title"></div>'+
        '<div class="mfp-counter"></div>'+
      '</div>'+
    '</div>',
    
      cursor: 'mfp-zoom-out-cur',
      titleSrc: 'title', 
      verticalFit: true, 
      tError: '<a href="%url%">The image</a> could not be loaded.'
    }
  });

  /*-------------functions---------------------*/
  // how to view layer
  var howToView = function() {
    var obj = $('.dd-b-how-to-view');
    obj.fadeIn();
    setTimeout(function() {
      obj.fadeOut();
    },3000);
  }
});
