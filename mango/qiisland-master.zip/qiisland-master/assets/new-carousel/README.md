# Vanilla JS Carousel
A sliding gallery made with css & vanilla js

# Getting started

1. Clone or download repo.
2. Open the repo and cd into your project.
3. Open the index.html in your browser or run ```open index.html``` in your terminal.