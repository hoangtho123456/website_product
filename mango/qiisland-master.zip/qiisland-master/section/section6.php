<section class="section fp-auto-height-responsive p-top7 animate-top7-js">
	<section class="p-top7__content1">
		<section class="container p-top7__box1">
			<h2 class="c-title1 a-hiddenTop">Tin tức</h2>
			
			<div class="row p-top7__list1 a-hiddenTop">
				<?php
				$arr_title = ["Bình dương ĐANG TRỞ THÀNH ĐẤT VÀNG",
				"CƠ HỘI SỞ HỮU 20 CĂN HỘ LOFT CUỐI  CÙNG TẠI qi island",
				"CUỐI NĂM DƯ TIỀN SĂN MUA CHUNG CƯ  CAO CẤP",
				"Qi Island - tiềm năng phát triển trong tương lai",
				"Bất động sản Bình Dương thăng hoa, dự án Qi Island hưởng lợi",
				"Thuận An và Dĩ An sắp lên thành phố"];
				// $arr_text = [
				// "Vị trí đắc địa; có quy mô lớn nhất khu vực Thuận An – Tỉnh Bình Dương với diện tích 32 ha",
				// "Dịp cuối năm, Thị trường BĐS Bình Dương sôi nổi với hàng loạt dự án được triển khai từ các chủ đầu tư lớn",
				// "Tháng 09/2019, HĐND tỉnh Bình Dương ban hành nghị quyết tán thành đề án thành lập TP Thuận An và Dĩ An",
				// ];
				$arr = ['banner1.jpg', 'pj5.png', 'pj6.png','pj1.jpg', 'pj2.jpg', 'pj3.jpg'];
				for($i = 0; $i < 6; $i++):
				?>
				<div class="col-md-6 col-lg-4 mb1 list1__order1">
					<div class="list1__card1">
						<a class="list1__link1 list1__content1" href="#">
							<div class="list1__img1 list1__coop<?php echo $i; ?>">
								<img data-src="assets/images/<?php echo $arr[$i];?>" alt="img1.png">
							</div>
							
							<div class="list1__box1">
								<h3 class="list1__title1"><?php echo $arr_title[$i]; ?></h3>
								<!-- <p class="date1">18/11/2019</p> -->
								<!-- <div class="list1__text1">
									<?php //echo $arr_text[$i]; ?>
								</div> -->
							</div>
						</a>
					</div>
				</div>
				<?php endfor; ?>

				<div class="p-top7__btn1">
					<a href="#" class="c-btn1">Xem thêm</a>
				</div>
			</div>

			<!-- <div class="p-top7__list1SP p-top7__list1SP-js a-hiddenTop">
				<div class="owl-carousel">
					<?php 
						for($i = 0; $i < 3; $i++):
					?>
					<div class="list1__card1">
						<a class="list1__link1 list1__content1" href="#">
							<div class="list1__img1">
								<img src="assets/images/img<?php echo $i + 1;?>.png" alt="img1.png">
							</div>
							
							<div class="list1__box1">
								<h3 class="list1__title1"><?php echo $arr_title[$i]; ?></h3>
								<p class="date1">18/11/2019</p>
							</div>
						</a>
					</div>
					<?php endfor; ?>
				</div>
			</div> -->
		</section>
	</section>
</section>
