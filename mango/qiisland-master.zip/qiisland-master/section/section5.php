<style>
  .p-top6 {
    background-image: url(assets/images/bg-news-pc.jpg);
  }
  @media only screen and (max-width: 767px) {
    .p-top6 { 
      background-image: <?php echo 'url(assets/images/bg-news.jpg);' ?>;
    }
  }
</style>

<section class="section p-top6 fp-auto-height-responsive___ animate-top6-js">
	<section class="p-top6__inner1">
		<h2 class="c-title1 a-hiddenTop">Hình ảnh dự án</h2>
		
		<div class="gallery-carousel gallery-carousel-3">
			<div class="gallery-container">
				<?php for($i =1; $i <= 3; $i++): ?>
					<div class="item gallery-item">
						<div class="inner"><img class="" src="assets/images/image<?php echo $i; ?>.jpg" alt="<?php echo $i; ?>"></div>
					</div>
				<?php endfor;?>
			</div>
			<div class="gallery-controls"></div>
		</div>
	</section>

	<div class="p-top6__circle1">
		<img src="assets/images/mask-circle.png" alt="mask-circle.png">
	</div>

	<script type='text/javascript' src='assets/new-carousel/carousel.js'></script>
</section>
