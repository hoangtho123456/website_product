<section class="section p-top5-new fp-auto-height-responsive dd-s-location">

      <div class="dd-b-location">
         <div class="dd-b-zoom desktop-hide tablet-hide"><a href="#" class="js-zoom-map"></a></div>
         <div class="dd-scroll-area">
            <div class="dd-map-hotpot dd-location-map" data-px-ratio="1" data-bg="assets/images/map-new.jpg">
              <img src="assets/images/map-new.jpg" alt="Location" class="js-current-bg dd-fullheight-banner">
              <a href="#" class="dd-hotpot is-eden" data-location-type="key" data-xy="-21 0">
                <!-- <img src="assets/images/bg-location.jpg" alt="Lancaster Lincoln"> -->
                <span class="dd-label">
                  <!--<span class="dd-bar dd-top"></span>
                  <span class="dd-bar dd-right dd-delay"></span><span class="dd-bar dd-bottom dd-delay"></span><span class="dd-bar dd-left"></span> -->
                  <img src="assets/images/logo-map1.png" alt="Island">
                </span>
              </a>
              <!--<span class="dd-hotpot is-area" data-location-type="key" data-place="" data-xy="-497 353"><span class="dd-label"><strong>Quận 1</strong> 10 phút - 5km</span></span>
              <span class="dd-hotpot is-area" data-location-type="key" data-place="" data-xy="-568 -195"><span class="dd-label"><strong>Quận Bình Thạnh</strong> 15 phút - 6km</span></span>
              <span class="dd-hotpot is-area" data-location-type="key" data-place="" data-xy="281 -89"><span class="dd-label"><strong>Thảo Điền</strong> 5 phút - 2km</span></span>
              <span class="dd-hotpot is-area" data-location-type="key" data-place="" data-xy="474 464"><span class="dd-label"><strong>Thủ Thiêm</strong> 9 phút - 4km</span></span> -->

              <!-- <span class="dd-hotpot group1 is-right" data-location-type="group1" data-place="KFC" data-xy="-325 249"></span> -->
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="Lotteria" data-xy="-203 -126"></span> -->
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="KFC chi nhánh 1" data-xy="-121 -134"></span> -->
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh Viện Quốc Tế 1" data-xy="-211 -45"></span>
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh Viện Quốc Tế 2" data-xy="5 -229"></span>
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh Viện Quốc Tế 3" data-xy="58 -229"></span>
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh viện quận 2" data-xy="207 -77"></span>
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh viện quận 2" data-xy="145 9"></span>
              <span class="dd-hotpot group2" data-location-type="group2" data-place="Bệnh viện quận 2" data-xy="229 90"></span>

              <span class="dd-hotpot group3" data-location-type="group3" data-place="Trung tâm thương mại Thảo Điền" data-xy="-10 -94"></span>
              <span class="dd-hotpot group3" data-location-type="group3" data-place="Trung tâm thương mại Thảo Điền 2" data-xy="26 -160"></span>
              <span class="dd-hotpot group3" data-location-type="group3" data-place="Trường Mầm Non An Phú" data-xy="324 159"></span>
              <span class="dd-hotpot group3" data-location-type="group3" data-place="Vincom Mega Mall Thảo Điền" data-xy="145 108"></span>
              <!-- <span class="dd-hotpot group3" data-location-type="group3" data-place="Parkson Cantavil" data-xy="535 -18"></span> -->
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="Lotteria 2" data-xy="434 268"></span>
              <span class="dd-hotpot group1" data-location-type="group1" data-place="Lotteria 3" data-xy="335 -164"></span> -->
              <span class="dd-hotpot group4" data-location-type="group4" data-place="Sân bóng nhân tạo 1" data-xy="-189 113"></span>
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="KFC2" data-xy="-456 -278"></span> -->
              <span class="dd-hotpot group5" data-location-type="group5" data-place="Bệnh Viện Điều Dưỡng Phục Hồi" data-xy="-143 -215"></span>
              <span class="dd-hotpot group5 is-right" data-location-type="group5" data-place="Trường Quốc Tế Đức - HCM" data-xy="104 -214"></span>
              <span class="dd-hotpot group5" data-location-type="group5" data-place="Trường Quốc Tế Đức - HCM" data-xy="100 -49"></span>
              <span class="dd-hotpot group5" data-location-type="group5" data-place="Trường THPT Thủ Thiêm" data-xy="256 -5"></span>
              <span class="dd-hotpot group5" data-location-type="group5" data-place="Trường THPT Thủ Thiêm" data-xy="336 -107"></span>
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="MM Megamarket" data-xy="396 13"></span> -->
              <!-- <span class="dd-hotpot group1" data-location-type="group1" data-place="KFC1" data-xy="377 -217"></span> -->

              <!-- <div class="map-texts">
                <div class="map-text1">
                  <p class="map-district">Quận Gò Vấp</p>
                  <p class="map-time">40 phút</p>
                </div>
                <div class="map-text1">
                  <p class="map-district">Sân bay Tân Sơn Nhất</p>
                  <p class="map-time">46 phút</p>
                </div>
                <div class="map-text1">
                  <p class="map-district">Bến xe miền đông</p>
                  <p class="map-time">34 phút</p>
                </div>
                <div class="map-text1">
                  <p class="map-district">Quận Bình Thạnh</p>
                  <p class="map-time">36 phút</p>
                </div>
                <div class="map-text1">
                  <p class="map-district">Quận 9</p>
                  <p class="map-time">43 phút</p>
                </div>
                <div class="map-text1">
                  <p class="map-district">Bến xe miền đông mới</p>
                  <p class="map-time">34 phút</p>
                </div>
              </div> -->  
            </div>
         </div>
      </div>
      <div class="dd-b-how-to-view">
         <span class="dd-icons"><span></span><span></span><span></span><span></span><span></span><span></span></span>
         <p>Vuốt ngang để xem toàn bộ</p>
      </div>
      <ul class="dd-location-filter">
        <li><a href="#" data-location="all" class="active dd-filter-all js-filter-location">Tất cả</a></li>
        <!-- <li><a href="#" data-location="group1" class="dd-filter-sport dd-filter-restaurant js-filter-location">Nhà hàng</a></li> -->
        <li><a href="#" data-location="group2" class="dd-filter-sport dd-filter-hospital js-filter-location">Bệnh viện</a></li>
        <li><a href="#" data-location="group3" class="dd-filter-sport dd-filter-shop js-filter-location">Trung tâm thương mại</a></li>
        <li><a href="#" data-location="group4" class="dd-filter-sport dd-filter-park js-filter-location">Công viên</a></li>
        <li><a href="#" data-location="group5" class="dd-filter-sport dd-filter-school js-filter-location">Trường học</a></li>
      </ul>

</section>


<!-- <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js'></script>  -->
<!-- <script type='text/javascript' src='assets/js/dd-location____.js'></script>  -->
<!-- <script type='text/javascript' src='assets/js/dd-location.js'></script>  -->

<!-- <script type='text/javascript'>
(function($){
    $(document).ready(function(){
    var $window = $(window);
    var $document = $(document);
    
    // scale the map (responsive)
    var scaleMap = function(scale) {
      var $this = $(this);
      var xy = $this.attr('data-xy').split(' ');
      var transX = parseFloat(xy[0]);
      var transY = parseFloat(xy[1]);
      var offsetX = $this.width() - $window.width();
      var offsetY = $this.height() - $window.height();
      if (offsetX > 0) {
        transX += (-offsetX / 2) / scale;
      }
      //don't deleted this below code for use soon
      // $this.css({
      //   //'scale(' + scale + ');
      //   'transform': 'translate( ' + transX + 'px,' + transY + 'px)',
      //   '-webkit-transform': ' translate( ' + transX + 'px,' + transY + 'px)',
      //   'moz-transform': 'translate( ' + transX + 'px,' + transY + 'px)',
      // });

      $this.css({
        //'scale(' + scale + ');
        'transform': 'scale(' + scale + ') translate( ' + transX + 'px,' + transY + 'px)',
        '-webkit-transform': 'scale(' + scale + ') translate( ' + transX + 'px,' + transY + 'px)',
        'moz-transform': 'scale(' + scale + ') translate( ' + transX + 'px,' + transY + 'px)',
      });
    }

        // calculate hotpot's positions for location page.
        var calcHotpotPos = function(map, checkWidth) {
          var sectionWrapper = map;
          var checkWidth = checkWidth;
            var scrollArea = map.parent();
            var sectionBg = new Image;
            sectionBg.src = sectionWrapper.attr('data-bg');
            var pxSize = parseInt(sectionWrapper.attr('data-px-ratio'));
            var originBgWidth, originBgHeight;
            var hotpots = sectionWrapper.find('.dd-hotpot');
            var curBg = map.find('.js-current-bg');
            var sectionWrapperX, curBgWidth, curBgHeight, lastX, gapX;
            var mapRatio = curBg.width()/ $window.width();

            var updateX = function(newX, newY) {
              sectionWrapper.css({
                'margin-left': newX + 'px',
                'margin-top': newY + 'px'
                  // 'transform': 'translate(' + newX + 'px)',
                  // '-webkit-transform': 'translate(' + newX + 'px)',
                  // 'moz-transform': 'translate(' + newX + 'px)'
              });
            }

            var dragBg = function(x, y) {
              curBgWidth = curBg.width();
              var winWidth = $window.width();
              var minX, maxX;

              if(curBgWidth > winWidth) {
                minX = -winWidth / 2;
                maxX = winWidth / 2 - curBgWidth;
                sectionWrapperX += (x - y) * mapRatio;
                // console.log(sectionWrapperX);
              if(sectionWrapperX >= minX) {
                sectionWrapperX = minX;
              } else {
                if(sectionWrapperX <= maxX) {
                  sectionWrapperX = maxX;
                }
              }
              updateX(sectionWrapperX);
              }

            // console.log((curX - lastX) * mapRatio + ' / ' + curX + ' / ' + lastX + ' / ' + mapRatio);
            lastX = x;
            }

            sectionBg.onload = function(e) {
              curBgWidth = curBg.width();
              curBgHeight = curBg.height();
              var winW = $window.width();

              if(winW > curBgWidth && checkWidth == true) {
                var scaleRatio = winW / curBgWidth;
                curBgHeight = curBgHeight * scaleRatio;
                curBgWidth = winW;
                curBg.width(curBgWidth);
                curBg.height(curBgHeight);
              }

              sectionWrapper.width(curBgWidth);
              sectionWrapper.height(curBgHeight);
              originBgWidth = sectionBg.width;
              originBgHeight = sectionBg.height;
                var scaleX = curBgWidth * pxSize / originBgWidth;
                var scaleY = curBgHeight * pxSize / originBgHeight;
                var scale = scaleX > scaleY ? scaleX : scaleY;
                sectionWrapperX = -curBgWidth / 2;
                sectionWrapperY = -curBgHeight / 2;
                updateX(sectionWrapperX, sectionWrapperY);
                hotpots.each(function() {
                    scaleMap.call(this, scale);
                });
            }

            // touchstart or mousedown
      // var canTouch = ('ontouchstart' in document.documentElement)  ? 'yes' : 'no';
      // var canTouch = $('html').hasClass('mobile');

      // // drag the map
      //     if(canTouch) {
      //   scrollArea.on({
      //           'touchstart': function(e) {
      //             lastX = e.changedTouches[0].pageX;
      //             // $.fn.fullpage.setAutoScrolling(false);
      //           },
      //           'touchmove': function(e) {
      //             var curX = e.changedTouches[0].pageX;
      //             dragBg(curX, lastX);
      //           },
      //           'touchend': function(e) {
      //             // $.fn.fullpage.setAutoScrolling(true);
      //           }
      //         });
      // } else {
      //   sectionWrapper.draggable({
      //     axis: "x",
      //     start: function(e) {
      //       lastX = e.pageX;
      //     },
      //     drag: function(e) {
      //       var curX = e.pageX;
      //       dragBg(curX, lastX);
      //     },
      //     stop: function() {}
      //   });
      // }
      $window.resize(function() {
        setTimeout(function(){
          curBg.removeAttr('style');
          sectionWrapper.removeAttr('style');
          curBgWidth = curBg.width();
          curBgHeight = curBg.height();
          var winW = $window.width();
          
          if(winW > curBgWidth && checkWidth == true) {
            var scaleRatio = winW / curBgWidth;
            curBgHeight = curBgHeight * scaleRatio;
            curBgWidth = winW;
            curBg.width(curBgWidth);
            curBg.height(curBgHeight);
          }

          mapRatio = curBg.width()/ $window.width();
          sectionWrapper.width(curBgWidth);
          sectionWrapper.height(curBgHeight);
          var scaleX = curBgWidth * pxSize / originBgWidth;
            var scaleY = curBgHeight * pxSize / originBgHeight;
            var scale = scaleX > scaleY ? scaleX : scaleY;
            sectionWrapperX = -curBgWidth / 2;
            sectionWrapperY = -curBgHeight / 2;
            updateX(sectionWrapperX, sectionWrapperY);
            hotpots.each(function() {
                scaleMap.call(this, scale);
            });
        },100);
      });
    }
      // init map & it's hotpots
      if($('.dd-location-map').length) {
        var map = $('.dd-location-map');
          calcHotpotPos(map, false);
          //projectHotpotController();
      }


        // filter location
        if($('.dd-location-filter').length) {
          $('.dd-location-filter').each(function(){
            var filter = $(this);
            var hotpots = filter.parent().find('.dd-hotpot');
            var filterOptions = filter.find('.js-filter-location');
            filterOptions.click(function(){
              var btn = $(this);
              btn.addClass('active').parent().siblings().find('a').removeClass('active');
              var showWhat = btn.attr('data-location');
              hotpots.removeClass('hide');
              console.log(showWhat);
              if(showWhat!='all'){
                hotpots.not('[data-location-type='+showWhat+'], [data-location-type=key]').addClass('hide');
              }
              // switch(showWhat) {
              //   case "all":
              //     // nothing
              //   break;
              //   case "group1":
              //     hotpots.not('[data-location-type=group1], [data-location-type=key]').addClass('hide');
              //   break;
              //   case "group2":
              //     hotpots.not('[data-location-type=group2], [data-location-type=key]').addClass('hide');
              //   break;
              //   case "group3":
              //     hotpots.not('[data-location-type=group3], [data-location-type=key]').addClass('hide');
              //   break;
              //   case "group4":
              //     hotpots.not('[data-location-type=group4], [data-location-type=key]').addClass('hide');
              //   break;
              //   case "group5":
              //     hotpots.not('[data-location-type=group5], [data-location-type=key]').addClass('hide');
              //   break;
              // }
              return false;
            });
          });
        }

        $('.js-zoom-map').on('click', function (e) {
          e.preventDefault();
          var body = $('body');
            body.toggleClass('map-zoom');
            if(body.hasClass('map-zoom')){
                var map = $('.dd-location-map');
                calcHotpotPos(map, true);
                //projectHotpotController();
                $.fn.fullpage.setMouseWheelScrolling(false);
                $.fn.fullpage.setAllowScrolling(false);
            }else{
                var map = $('.dd-location-map');
                map.css({
                  'height': $(window).height()
                })
                calcHotpotPos(map, false);
                $.fn.fullpage.setMouseWheelScrolling(true);
                $.fn.fullpage.setAllowScrolling(true);
            }
        })
    }); 
})(jQuery); 
</script> -->



