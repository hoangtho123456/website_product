<section class="section p-top5">
  <section class="p-top5__content1">
    <section class="p-top5__box1">
      <article class="box1">
        <div class="map-img1">
          <img src="assets/images/map.png" alt="map.png">
        </div>
        <div class="map-list1 map-list1-js">
          <a class="map-icon1 btn-js" href="#">
            <img src="assets/images/group2.png" alt="group">
          </a>
          <a class="map-icon1 btn1-js" href="#">
            <img src="assets/images/group5.png" alt="group">
          </a>
          <a class="map-icon1 btn2-js" href="#">
            <img src="assets/images/group3.png" alt="group">
          </a>
          <a class="map-icon1 btn3-js" href="#">
            <img src="assets/images/group1.png" alt="group">
          </a>
          <a class="map-icon1 btn4-js" href="#">
            <img src="assets/images/group2.png" alt="group">
          </a>
          <a class="map-icon1 btn5-js" href="#">
            <img src="assets/images/group4.png" alt="group">
          </a>
          <a class="map-icon1 btn6-js" href="#">
            <img src="assets/images/group6.png" alt="group">
          </a>
        </div>
        <div class="map-icons map-type1 icons-js" data-typemap="type1">
          <?php for($i = 0; $i < 4; $i++): ?>
          <div class="map-icon1">
            <img src="assets/images/group5.png" alt="group">
          </div>
          <?php endfor;?>
        </div>
        <div class="map-icons map-type2 icons-js" data-typemap="type2">
          <?php for($i = 0; $i < 6; $i++): ?>
          <div class="map-icon1">
            <img src="assets/images/book.png" alt="group">
          </div>
          <?php endfor;?>
        </div>
        <div class="map-icons map-type3 icons-js" data-typemap="type1">
          <?php for($i = 0; $i < 6; $i++): ?>
          <div class="map-icon1">
            <img src="assets/images/group3.png" alt="group">
          </div>
          <?php endfor;?>
        </div>
        <div class="map-icons map-type4 icons-js" data-typemap="type1">
          <?php for($i = 0; $i < 6; $i++): ?>
          <div class="map-icon1">
            <img src="assets/images/group4.png" alt="group">
          </div>
          <?php endfor;?>
        </div>
        <div class="map-icons map-type5 icons-js" data-typemap="type1">
          <?php for($i = 0; $i < 1; $i++): ?>
          <div class="map-icon1">
            <img src="assets/images/group1.png" alt="group">
          </div>
          <?php endfor;?>
        </div>
        <div class="map-texts">
          <a class="map-text1" href="#">
            <p class="map-district">Quận Gò Vấp</p>
            <p class="map-time">40 phút</p>
          </a>
          <div class="map-text1">
            <p class="map-district">Quận Gò Vấp</p>
            <p class="map-time">40 phút</p>
          </div>
          <div class="map-text1">
            <p class="map-district">Sân bay Tân Sơn Nhất</p>
            <p class="map-time">46 phút</p>
          </div>
          <div class="map-text1">
            <p class="map-district">Bến xe miền đông</p>
            <p class="map-time">34 phút</p>
          </div>
          <div class="map-text1">
            <p class="map-district">Quận Bình Thạnh</p>
            <p class="map-time">36 phút</p>
          </div>
          <div class="map-text1">
            <p class="map-district">Quận 9</p>
            <p class="map-time">43 phút</p>
          </div>
          <div class="map-text1">
            <p class="map-district">Bến xe miền đông mới</p>
            <p class="map-time">34 phút</p>
          </div>
        </div>
        <div class="bg-bottom"></div>
      </article>
    </section>
  </section>
</section>