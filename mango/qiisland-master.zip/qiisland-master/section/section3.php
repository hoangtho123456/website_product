<?php $count = 4; ?>

<?php
$arr_img = ["tree.svg","book.svg","shop.svg", "water.svg"];
$arr_lb = ["tree-lb.svg", "book-lb.svg", "shop-lb.svg", "water-lb.svg"]; //"shop-lb.svg"
$arr_lb_sp = ["tree-lb.svg", "book-lb.svg", "shop-lb.svg", "water-lb.svg"]; //"shop-lb.svg"
$arr_title = ["HỆ SINH THÁI XANH<br> <strong>BAO PHỦ 360 ĐỘ</strong>", 
            "TỔ HỢP <br><strong>TRƯỜNG HỌC LIÊN CẤP</strong>", "TỔ HỢP TRUNG TÂM <strong>THƯƠNG MẠI ĐẲNG CẤP</strong>", 
            "HỆ THỐNG XỬ LÝ <br> <strong>NƯỚC THẢI TẬP TRUNG</strong>"];
$arr_content = ["Cùng với dòng nước mát lành bao quanh, sắc xanh tươi mát bao phủ 360 độ 
                với công viên nội khu .. ha và hàng ngàn mảng xanh sẽ mang đến cho quý cư dân Qi island một không gian sống chuẩn resort, khoáng đạt và yên bình.",
               "Tổ hợp trường học liên cấp theo tiêu chuẩn quốc tế gồm trường mầm non, tiểu học và trung học cơ sở sẽ giúp quý cư dân Qi island an tâm kiến tạo tương lai trí thức cho con trẻ.",
               "Một tổ hợp trung tâm thương mại hiện đại, quy tụ các thương hiệu thời trang, tiêu dùng, ẩm thực đẳng cấp, mang đến cho quý cư dân Qi island những trải nghiệm dịch vụ thời thượng, nhanh chóng và tiện lợi nhất.",
               "Được vận hành với công nghệ hiện đại đạt chuẩn quốc tế, hệ thống xử lý nước thải tập trung thông minh sẽ bảo vệ môi trường sống trong lành, tinh khiết cho quý cư dân Qi island."
            ];
?>


   <section class="section p-top3-new animate-top3-js">
      <div class="p-top3__box1">
        <div class="utilities-wrap">
           <div class="utilities-list">
              <div class="utilities-circle">
                 <div class="utilities-spin">
                    <div class="utilities-list-item" id="list-icon-utilitis">
                       <ul>
                          <?php for($i=1;$i<=$count;$i++) { ?>
                          <li>
                             <div class="icon-utilitis-wrap">
                                <a href="#" id="utiliti-<?php echo $i; ?>" class=" <?php if($i==3) echo 'active'; ?>" data-img="assets/images/banner3-<?php echo $i; ?>.jpg">
                                   <div class="icon-utilitis">
                                      <img data-src="assets/images/<?php echo $arr_img[$i - 1];?>" alt="<?php echo $i; ?>">
                                    </div>
                                </a>
                             </div>
                          </li>
                          <?php } ?>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>

           <div class="ulilities-bg"><img id="ulilities-bg-placeholder" src="" alt="" /></div>
           <div class="ulilities-content">
              <?php for($i=1;$i<=$count;$i++) { ?>
              <div class="utiliti-content-wrap <?php if($i==3) echo 'utiliti-content-active'; ?>" id="utiliti-content-<?php echo $i; ?>">
                 <div class="decription-for-utilities-wrap">
                    <div class="decription-for-utilities">
                       <div class="utiliti-name a-hiddenTop">
                         <img data-src="assets/images/<?php echo $arr_lb[$i - 1];?>" alt="<?php echo $i; ?>">
                         <h2><?php echo $arr_title[$i - 1]; ?></h2>
                       </div>
                       <div class="decription-for-utilitie-p a-hiddenTop">
                          <p><?php echo $arr_content[$i - 1]; ?></p>
                       </div>
                       <!--<a href="/amenities" class="btn-seemore btn-utiliti">--><!--<span>Xem thêm</span>--><!--</a>-->
                    </div>
                 </div>
              </div>
              <?php } ?>
           </div>
        </div>
      </div>

      <div class="p-top3__box1SP">
        <div class="list1 top3-list1-js">
          <div class="owl-carousel">
            <div class="list1__card1">
              <!-- <div class="ulilities-content"> utiliti-content-wrap-->
                <div class="list1__box1">
                  <div class="decription-for-utilities-wrap">
                    <div class="decription-for-utilities">
                      <div class="utiliti-name a-hiddenTop">
                        <img src="assets/images/<?php echo $arr_lb_sp[2];?>" alt="<?php echo 2; ?>">
                        <h2><?php echo $arr_title[2]; ?></h2>
                      </div>
                      
                      <div class="decription-for-utilitie-p a-hiddenTop">
                        <p><?php echo $arr_content[2]; ?></p>
                       </div>
                       <!--<a href="/amenities" class="btn-seemore btn-utiliti">--><!--<span>Xem thêm</span>--><!--</a>-->
                    </div>
                 </div>
                </div>
              <!-- </div> -->

              <div class="list1-bg1">
                <img src="assets/images/banner3-<?php echo 3; ?>sp.jpg" alt="banner.jpg">
              </div>
            </div>

            <?php for($i = 0; $i < 4; $i++): 
              if($i !== 2):?>
            <div class="list1__card1">
              <!-- <div class="list1__box1">
                <h2 class="info1__title1 a-hiddenTop"><?php echo $arr_title[$i]; ?></h2>
                <div class="info1__content1 a-hiddenTop">
                  <div class="img1">
                    <img src="assets/images/<?php echo $arr_img[$i];?>" alt="logo">
                  </div>
                  <p><?php echo $arr_content[$i]; ?></p>
                </div>
              </div> -->

              <!-- <div class="ulilities-content"> utiliti-content-wrap-->
                <div class="list1__box1">
                  <div class="decription-for-utilities-wrap">
                    <div class="decription-for-utilities">
                      <div class="utiliti-name a-hiddenTop">
                        <img src="assets/images/<?php echo $arr_lb[$i];?>" alt="<?php echo $i; ?>">
                        <h2><?php echo $arr_title[$i]; ?></h2>
                      </div>
                      
                      <div class="decription-for-utilitie-p a-hiddenTop">
                        <p><?php echo $arr_content[$i]; ?></p>
                       </div>
                       <!--<a href="/amenities" class="btn-seemore btn-utiliti">--><!--<span>Xem thêm</span>--><!--</a>-->
                    </div>
                 </div>
                </div>
              <!-- </div> -->

              <div class="list1-bg1">
                <img src="assets/images/banner3-<?php echo $i + 1; ?>.jpg" alt="banner.jpg">
              </div>
            </div>
            <?php endif; endfor; ?>
          </div>
        </div>
      </div>

      <!-- <link href="http://lincoln.lancaster.com.vn__/combine/79cbd7caecd22f6a81d2c3e27a7b2382-1547438300" rel="stylesheet" media="screen" /> -->

      <script src="assets/js/ulilities-slide.js"></script>

   </section>
