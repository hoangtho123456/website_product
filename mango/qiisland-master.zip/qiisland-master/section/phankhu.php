<section data-tooltip="Thông tin chi tiết" class="section fp-auto-height-responsive dd-s-project-overview">
    <div class="dd-project-breadcrumb">
        <a href="#" class="js-back"><img src="http://eden.lancaster.com.vn/themes/eden/assets/images/thumbnail-eden.png" alt="Lancaster Eden" class="dd-thumbnail"></a><span class="dd-hotpot" data-place=""></span>
        <p class="dd-cur-slide js-breadcrumb-title"></p>
        <p class="dd-back"><a href="#" class="js-back">Thông tin chi tiết</a><span class="js-breadcrumb-title"></span></p>
    </div>
    <div class="dd-project-info">
        <div class="dd-b-head"><a href="#" class="dd-read-more js-read-more">Đọc Thêm</a>
            <h2 class="js-open-info"></h2><a href="#" class="dd-back js-back">Quay lại Thông Tin Chi Tiết</a></div>
        <div class="dd-b-body"><a href="#" class="dd-close js-close-info">Đóng</a>
            <div class="js-content-info"></div>
        </div>
    </div>
    <div class="dd-garden-popin">
        <div class="dd-b-head">
            <a href="#" class="dd-close js-close-flower"></a>
            <h2 class="js-flower-heading"></h2>
            <p class="dd-desc js-flower-desc"></p>
        </div>
        <div class="dd-b-body">
            <div class="dd-garden-slider dd-hoa-trang-tri">
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-bienhoasonghang.png" alt="BIẾN HOA SÔNG HẰNG"></div>
                    <p class="dd-lang-vn">BIẾN HOA SÔNG HẰNG</p>
                    <p class="dd-lang-en">Asystasia Gangetica</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-duoicong.png" alt="ĐUÔI CÔNG"></div>
                    <p class="dd-lang-vn">ĐUÔI CÔNG</p>
                    <p class="dd-lang-en">Calathea Loeseneri</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-lodanh.png" alt="LỖ DANH"></div>
                    <p class="dd-lang-vn">LỖ DANH</p>
                    <p class="dd-lang-en">Hippobroma Longiflora</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-bachtrinh.png" alt="BẠCH TRINH"></div>
                    <p class="dd-lang-vn">BẠCH TRINH</p>
                    <p class="dd-lang-en">Hymenocallis Speciosa</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-muonghoadao.png" alt="MUỒNG HOA ĐÀO"></div>
                    <p class="dd-lang-vn">MUỒNG HOA ĐÀO</p>
                    <p class="dd-lang-en">Cassia Javanica</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-lanrequat.png" alt="LAN RẺ QUẠT"></div>
                    <p class="dd-lang-vn">LAN RẺ QUẠT</p>
                    <p class="dd-lang-en">Neomarica Longifolia</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-bachtrinh2.png" alt="BẠCH TRINH"></div>
                    <p class="dd-lang-vn">BẠCH TRINH</p>
                    <p class="dd-lang-en">Hymenocallis Speciosa</p>
                </div>
            </div>
            <div class="dd-garden-slider dd-hoa-phu-tuong">
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-diepvang.png" alt="Điệp vàng"></div>
                    <p class="dd-lang-vn">Điệp vàng</p>
                    <p class="dd-lang-en">Epipremnum Aureum</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-camnhung.png" alt="CẨM NHUNG"></div>
                    <p class="dd-lang-vn">CẨM NHUNG</p>
                    <p class="dd-lang-en">Fittonia Verschaffeltii</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-duacanhmautu.png" alt="DỨA CẢNH MẪU TỬ"></div>
                    <p class="dd-lang-vn">DỨA CẢNH MẪU TỬ</p>
                    <p class="dd-lang-en">Neoregelia</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-duongxi.png" alt="DƯƠNG XỈ"></div>
                    <p class="dd-lang-vn">DƯƠNG XỈ</p>
                    <p class="dd-lang-en">Nephrolepis Cordifolia</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-machmon.png" alt="MẠCH MÔN"></div>
                    <p class="dd-lang-vn">MẠCH MÔN</p>
                    <p class="dd-lang-en">Ophiopogon Jaburan</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/flower-tradescantia-spathacea.png" alt="Sò Huyết"></div>
                    <p class="dd-lang-vn">Sò Huyết</p>
                    <p class="dd-lang-en">Tradescantia Spathacea</p>
                </div>
            </div>
            <div class="dd-garden-slider dd-cay-xanh">
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/tree-chichieulieu.png" alt="CHI CHIÊU LIÊU"></div>
                    <p class="dd-lang-vn">CHI CHIÊU LIÊU</p>
                    <p class="dd-lang-en">Terminalia Ivorensis</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/tree-diepvang.png" alt="HOA SỨ"></div>
                    <p class="dd-lang-vn">HOA SỨ</p>
                    <p class="dd-lang-en">lumeria</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/tree-metay.png" alt="ME TÂY"></div>
                    <p class="dd-lang-vn">ME TÂY</p>
                    <p class="dd-lang-en">Samanea Saman</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/tree-muonghoadao.png" alt="MUỒNG HOA ĐÀO"></div>
                    <p class="dd-lang-vn">MUỒNG HOA ĐÀO</p>
                    <p class="dd-lang-en">Cassia Javanica</p>
                </div>
                <div>
                    <div class="dd-photo"><img src="http://eden.lancaster.com.vn/storage/app/media/tree-diepvang.png" alt="ĐIỆP VÀNG"></div>
                    <p class="dd-lang-vn">ĐIỆP VÀNG</p>
                    <p class="dd-lang-en">Cassia Hebecarpa</p>
                </div>
            </div>
        </div>
    </div>
    <div class="dd-club-popin">
        <div class="dd-b-head">
            <a href="#" class="dd-close js-close-club"></a>
            <h2 class="js-club-heading"></h2></div>
        <div class="dd-b-body">
            <div class="dd-b-photo">
                <div class="dd-photo"><img src="" alt="Photo" class="js-club-photo"></div>
                <div class="dd-mini-map"><img src="" alt="Map" class="js-club-mini-map"></div>
            </div>
        </div>
    </div>
    <div class="dd-project-slide active dd-eden-map js-project-hotpot-controller">
        <div class="dd-scroll-area">
            <div class="dd-map-hotpot dd-project-map" data-px-ratio="1" data-bg="http://eden.lancaster.com.vn/themes/eden/assets/images/map-eden.jpg"><img src="http://eden.lancaster.com.vn/themes/eden/assets/images/map-eden.jpg" alt="Lancaster Eden" class="js-current-bg dd-fullheight-banner"><a href="http://eden.lancaster.com.vn/villa/jasmine" class="dd-hotpot" data-place="Jasmine Villa" data-xy="-282 200"><span></span></a><a href="http://eden.lancaster.com.vn/villa/camellia" class="dd-hotpot" data-place="Camellia Villa" data-xy="118 -376"><span></span></a><a href="http://eden.lancaster.com.vn/villa/iris" class="dd-hotpot" data-place="Iris Villa" data-xy="-162 -303"><span></span></a><a href="http://eden.lancaster.com.vn/villa/peony" class="dd-hotpot" data-place="Peony Villa" data-xy="252 -233"><span></span></a><a href="http://eden.lancaster.com.vn/villa/orchid" class="dd-hotpot" data-place="Orchid Villa" data-xy="-77 106"><span></span></a><span class="dd-hotpot dd-hotpot-internal" data-heading="Club <strong>House</strong>" data-info="<p>Không gian thư giãn đặc quyền của những chủ nhân thượng lưu. Nơi nguồn năng lượng sống được tái tạo không ngừng.</p>" data-thumb-xy="25 43" data-class="dd-club-house" data-place="CLUB HOUSE" data-version="standard" data-xy="-407 -136"><span></span></span><span class="dd-hotpot dd-hotpot-internal is-active" data-heading="Vườn <strong>Eden</strong>" data-info="<p>Một tác phẩm nghệ thuật thiên nhiên ngay trong tầm mắt. Đây thực sự là nơi dành cho mọi thế hệ bởi mỗi sự sắp đặt đều có chủ ý. Người lớn tuổi tận hưởng an yên, con trẻ thỏa thích vui đùa. Không khí trong lành, xanh mát cùng tiếng róc rách của nước, hương thơm ngát của  cỏ cây…tất cả hoà quyện vỗ về cho tâm hồn thư thái. Điểm gặp gỡ lý tưởng giữa các gia đình hay đơn giản là nơi dừng chân thư giãn, thưởng thức tuyệt cảnh trên con đường đầy hoa dẫn đến villa riêng tư của mình.</p>" data-thumb-xy="60 42" data-class="dd-vuon-eden" data-place="VƯỜN EDEN" data-version="standard" data-xy="51 -210"><span></span></span><span class="dd-hotpot dd-hotpot-internal is-active" data-heading="Hầm <strong>Ánh Sáng</strong>" data-info="<p>Một không gian rộng và phóng khoáng lên đến 8000m2. Tất cả được bố trí khéo léo ẩn dưới khu vườn trung tâm với hệ thống giếng trời cho ánh sáng tự nhiên thoáng đãng. Không đơn thuần là một nơi dừng đỗ xe, đây còn là một bức tranh thiên đường đầy ánh sáng.</p><p>Đảm bảo chức năng nhưng không phá vỡ tính thẩm mỹ. Mỗi cảnh quan tại tầng hầm đều được chăm chút tỉ mỉ bằng những mảng xanh hoặc tô điểm bằng các tác phẩm điêu khắc, trang trí riêng tại mỗi ngôi nhà. Hệ thống giao thông ngầm được tính toán khoa học để đảm bảo sự yên tĩnh và mỹ quan tuyệt đối cho toàn khu.</p>" data-thumb-xy="60 45" data-class="dd-ham-anh-sang" data-place="HẦM ÁNH SÁNG" data-version="standard" data-xy="-132 -122"><span></span></span><span class="dd-hotpot dd-hotpot-internal" data-heading="Lối <strong>Vào Chính</strong>" data-info="<p>Sự ấn tượng là cảm giác đầu tiên có thể cảm nhận ngay từ khi đặt chân vào khuôn viên Lancaster Eden. Đan xen tinh tế giữa cảnh quan xanh, mặt nước và các vật liệu tự nhiên tạo nên sự sang trọng không hề phô diễn.</p><p>Một không gian khép kín dành riêng cho những người sở hữu. Nơi an ninh được đảm bảo ở mức tối đa với đội ngũ nhân viên chuyên nghiệp, hệ thống CCTV 24/7, điểm truy cập bằng thẻ dành cho cả phương tiện và người đi bộ.</p><p><br></p><p><br></p>" data-thumb-xy="16 67" data-class="dd-loi-vao-chinh" data-place="LỐI VÀO CHÍNH" data-version="standard" data-xy="-438 68"><span></span></span><span class="dd-hotpot not-link" data-heading="" data-info="" data-thumb-xy="131 49" data-class="#" data-place="Lối vào phụ" data-version="standard" data-xy="511 -116"><span></span></span>
            </div>
        </div>
        <div class="dd-b-how-to-view"><span class="dd-icons"><span></span><span></span><span></span><span></span><span></span><span></span></span>
            <p>Vuốt ngang để xem toàn bộ</p>
        </div><span class="dd-compass"></span><span class="dd-project-overview-decor"></span></div>



</section>
