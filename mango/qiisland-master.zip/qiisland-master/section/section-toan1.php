<style>
  .p-top1 {
    background-image: url(assets/images/bgslide1-pc.jpg);
  }
  @media only screen and (max-width: 767px) {
    .p-top1 { 
      background-image: <?php echo 'url(assets/images/bgslide1-sp.jpg);' ?>;
    }
  }
</style>

<section class="wrap-multi-slide section p-top1">
  <div class="container" >

    <div class="row">
      <div class="col-md-4">

        <div class="slick-slide-1">
          <?php 
          $arr_content = [
            "Đại đô thị cao cấp Qi island - Một ốc đảo xanh yên bình kết nối 2 thành phố năng động bậc nhất là Sài Gòn & Bình Dương.",
            "Qi island là sự kết hợp hài hòa giữa kiến trúc hiện đại & sắc xanh tươi sáng của miền thiên nhiên thuần khiết, cùng dòng nước mát lành bao quanh.",
            "Qi island là sự trở về với ngôi nhà ấm áp, ngập tràn yêu thương trong không gian sống thông minh, tiện nghi & đẳng cấp.",
            "Qi island chính là lựa chọn duy nhất cho những cư dân thông thái mong muốn nâng tầm chất lượng cuộc sống với 3 KẾT NỐI VÀNG: Kết nối địa lý - Kết nối thiên nhiên – Kết nối công nghệ."
          ];
          for($i=1;$i<=4;$i++){ ?>
          <div class="item">  
              <div class="desc">

                <p><?php echo $arr_content[$i - 1];?></p>

              </div>
          </div>
          <?php } ?>
        </div>

      </div>    
      <div class="col-md-8">


        <div class="row group-slide">
          <div class="col-4">
            <div class="slick-slide-2">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>   
          </div>  
          <div class="col-4">
            <div class="slick-slide-3">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>  
          </div> 
          <div class="col-4"> 
            <div class="slick-slide-4">
              <?php for($i=1;$i<=4;$i++){ ?>
              <div class="item ">
                <!-- <div class="img"><img src="assets/slick-multi/<?php //echo $i; ?>.jpg" /></div> -->
                <div class="img"><img data-src="assets/images/multi/img<?php echo $i; ?>.jpg" /></div>
              </div>
              <?php } ?>
            </div>   
          </div>      
        </div>        
        
      </div>    
    </div>

  </div>


  
  <script type='text/javascript' src='https://code.jquery.com/jquery-1.11.0.min.js'></script> 
<script type='text/javascript' src='https://kenwheeler.github.io/slick/slick/slick.js'></script> 


<script type="text/javascript">
// JavaScript Document
(function($){
    $(document).ready(function(){

        const $slider = $(".slick-slide-1");
        const $slider2 = $(".slick-slide-2");
        const $slider3 = $(".slick-slide-3");
        const $slider4 = $(".slick-slide-4");
        $slider.slick({
            dots: false,
            fade: true,
            infinite: true,
            autoplay:true,
            autoplaySpeed: 10000,
            slidesToShow: 1,
            slidesToScroll: 1,     
            asNavFor: '.slick-slide-2,.slick-slide-3,.slick-slide-4',       
        })


        $slider2.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,    
            asNavFor: '.slick-slide-1',       
        })  
        $slider3.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,   
            asNavFor: '.slick-slide-1',       
        })  
        $slider4.slick({
            arrows : false,
            dots: false,
            vertical: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1, 
            asNavFor: '.slick-slide-1',      
        })  


        function mouseWheel($slider) {
          $(window).on('wheel', { $slider: $slider }, mouseWheelHandler)
        }
        function mouseWheelHandler(event) {
          event.preventDefault()
          const $slider = event.data.$slider
          const delta = event.originalEvent.deltaY
          if(delta > 0) {
            $slider.slick('slickPrev')
          }
          else {
            $slider.slick('slickNext')
          }
        }



    }); 

})(jQuery); 
    
</script>
</section>

