<section class="section p-top1 group-ef lazy-hidden">
  <section class="p-top1__content1">
    <section class="container p-top1__box1 animate-top1-js">
      <article class="box1">
        <h2 class="c-title1 a-hiddenTop">Giới thiệu</h2>
        
        <div class="text1 a-hiddenTop">
          <p>Đại đô thị cao cấp Qi island - Một ốc đảo xanh yên bình kết nối 2 thành phố năng động bậc nhất là Sài Gòn & Bình Dương.</p>
          <p>Qi island là sự kết hợp hài hòa giữa kiến trúc hiện đại & sắc xanh tươi sáng của miền thiên nhiên thuần khiết, cùng dòng nước mát lành bao quanh.</p>
          <p>Qi island là sự trở về với ngôi nhà ấm áp, ngập tràn yêu thương trong không gian sống thông minh, tiện nghi & đẳng cấp.</p>
          <p>Qi island chính là lựa chọn duy nhất cho những cư dân thông thái mong muốn nâng tầm chất lượng cuộc sống với 3 KẾT NỐI VÀNG: Kết nối địa lý -  Kết nối thiên nhiên – Kết nối công nghệ.</p>
        </div>
      </article>
    </section>
    <div class="p-top1__circle1"><img src="assets/images/mask-circle.png" alt="mask-circle.png"></div>
    <div class="p-top1__bg1"><img src="assets/images/banner2.jpg" alt="banner2.jpg"></div>
  </section>
</section>
