<?php include 'include/index-top-1.php';?>
  
<main class="l-main">
	<section class="p-news1">
		<div class="p-news1__bg">
			<img src="assets/images/bg-news-pc.jpg" alt="bg-news-pc.jpg">
		</div>
		<div class="container">
			<h2 class="c-title1 c-title1--type1">Tin tức</h2>
			
			<div class="p-news1__list1">
				<section class="c-rowlist1 row">
					<?php
					$arr_title = ["Bình dương ĐANG TRỞ THÀNH ĐẤT VÀNG",
					"CƠ HỘI SỞ HỮU 20 CĂN HỘ LOFT CUỐI  CÙNG TẠI qi island",
					"CUỐI NĂM DƯ TIỀN SĂN MUA CHUNG CƯ  CAO CẤP",
					"Bình dương ĐANG TRỞ THÀNH ĐẤT VÀNG",
					"CƠ HỘI SỞ HỮU 20 CĂN HỘ LOFT CUỐI  CÙNG TẠI qi island",
					"CUỐI NĂM DƯ TIỀN SĂN MUA CHUNG CƯ  CAO CẤP",
					"Bình dương ĐANG TRỞ THÀNH ĐẤT VÀNG",
					"CƠ HỘI SỞ HỮU 20 CĂN HỘ LOFT CUỐI  CÙNG TẠI qi island",
					"CUỐI NĂM DƯ TIỀN SĂN MUA CHUNG CƯ  CAO CẤP"];
					$arr = ['pj1.jpg', 'pj2.jpg', 'pj3.jpg',
						'pj4.jpg', 'pj5.jpg', 'pj6.jpg',
						'pj7.jpg', 'pj8.jpg', 'pj9.jpg'];
					for($i = 0; $i < 9; $i++):
					?>
					<div class="col-sm-6 col-md-6 col-lg-4 list1__card1">
						<a class="list1__content1" href="#">
							<div class="list1__img1">
								<img src="assets/images/news/<?php echo $arr[$i];?>" alt="img1.png">
							</div>
							
							<div class="list1__box1">
								<h3 class="list1__title1"><?php echo $arr_title[$i]; ?></h3>
							</div>
						</a>
					</div>
					<?php endfor; ?>		
				</section>
			</div>

			<div class="p-news1__btn1">
				<a href="#" class="c-btn1">Xem thêm</a>
			</div>
		</div>
	</section>
</main>

<?php include 'include/index-bottom-1.php';?>
