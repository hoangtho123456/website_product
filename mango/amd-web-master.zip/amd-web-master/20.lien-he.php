<?php include 'include/index-top.php';?>
<main id="main" class="page-lien-he  lazy lazy-hidden" data-lazy-type="bg" data-lazy-src="assets/images/bg-11.jpg">
  <div class="container"> 
    <div class=" max570">


      <div class="section-header">
        <h1 class="section-title page-title"><span>LIÊN HỆ</span></h1>
      </div>


      <form action="" class="labelblock">
        <div class="row">
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Họ và tên</span>
              <input placeholder="Họ và tên" type="text" class="input">
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Điện thoại</span>
              <input placeholder="Điện thoại" type="text" class="input">
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Email</span>
              <input placeholder="Email" type="email" class="input">
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Nội dung</span>
              <textarea name="" id="" cols="30" rows="10" class="input h50"></textarea>
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <button class="btn"><span>Gửi liên hệ</span></button>

          </div>
        </div>
      </form>





    </div>
 
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

