<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
  <section class="am08">
    <div class="container"> 
      <div class="row followHeight">
        <div class="col-md-8">
          <div class="img clearfix equal2">
            <img class="lazy lazy-hidden imgres" width="879" height="449" src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="assets/images/img-3.jpg" alt="alt"
           />
           </div>
        </div>
        <div class="col-md-4">
          <div class="dl-table">
            <div class="col-md-12 equal1">
              <div class="divtex">
                <h2 class="title"><span>Banner khuyến mãi</span></h2>
                <p>Tụ tập cùng bạn bè và cố gắng sống sót trước bè lũ thây ma cùng đồ họa AMD Radeon™ và bộ xử lý Ryzen™.                </p>

              </div>  
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>  

<main id="main" class="page-khuyen-mai section-t" >
  <div class="container"> 

 
    <div class="entry-content max970">
      <h1 >Exclusive Beachfront Luxury Apartment, Hyatt Regency</h1>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
    </div>
    <section class=" am24">
      <h4>Các bài viết liên quan</h4>
        <div class="row layout-1 list-item-b50">
          <?php
          for($i=1;$i<=3;$i++){ 
            $img = 'https://via.placeholder.com/360x250';
            $title = 'Công nghệ AMD SenseMI';
            $desc = 'Được kiến tạo dựa trên công nghệ AMD SenseMI mang đến một bộ vi xử lý thông minh đúng nghĩa. Hiệu năng nâng cấp mạnh mẽ hơn với';
            ?>
            <div class="col-sm-4 col-md-4">
              <?php include 'repeat/layout-1.php';?>
            </div>  
          <?php
          }?>
        </div>   
    </section>       
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

