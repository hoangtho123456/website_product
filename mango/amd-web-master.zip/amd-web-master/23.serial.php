<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
<main id="main" class="section page-serial-2 bgt0"  >
  <div class="container"> 
    <div class=" max570">






      <div class="section-header text-center">
        <h1><span>Kiểm tra hàng chính hãng</span></h1>
      </div>  

      <div class="divtext">
        <div class="text-center">Sản phẩm này không phải là hàng chính hãng của AMD</div>
      </div>
      




    </div>
 
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

