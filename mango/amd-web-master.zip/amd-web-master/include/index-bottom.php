	<footer id="footer" class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<p class="uppercase">Ornare pellentesque tempor tempor  sollicitudin sociis duis dapibus. </p>
					<p class="info">
						<span class="key">Address:</span> <br> 
						Tầng 9. Paxsky, 13-15-17 Trương Định, P6, quận 3, TPHCM, Việt Nam <br>
						<span class="key">Email:</span> <br> 
						<a href="mailto:hotro@amdvietnam.com.vn">hotro@amdvietnam.com.vn</a><br>
						<a href="mailto:baohanh@amdvietnam.com.vn">baohanh@amdvietnam.com.vn</a><br>
					</p>
					<div class="social">
						<a href="#" class="tw"><i class="icon-twitter"></i></a>
						<a href="https://www.facebook.com/AMDVN" class="fb"><i class="icon-facebook"></i></a>
						<a href="#" class="you"><i class="icon-youtube-2"></i></a>
						<a href="#" class="ma"><i class="icon-mail-2"></i></a>
					</div>
				</div>
				<div class="col-md-3">
					<ul class="menu">
						<li><a href="#">Trang chủ</a></li>
						<li><a href="#">CPU</a></li>
						<li><a href="#">GPU</a></li>
						<li><a href="#">Sự kiện</a></li>
						<li><a href="#">Đánh giá sản phẩm</a></li>

					</ul>
				</div>
				<div class="col-md-3">
					<ul class="menu">
						<li><a href="">Chính sách bảo hành</a></li>
						<li><a href="">Hỗ trợ kỹ thuật</a></li>
						<li><a href="">Ước tính cấu hình mong muốn</a></li>
						<li><a href="">Kiểm tra hàng chính hãng</a></li>
						<li><a href="">Hỏi đáp</a></li>
					</ul>
				</div>
				<div class="col-md-3">
					<ul class="menu">
						<li><a href="">Công nghệ</a></li>
						<li><a href="">Tuyển dụng</a></li>
						<li><a href="">Khuyến mãi</a></li>
						<li><a href="">Liên hệ</a></li>
						<li><a href="">Tìm đại lý gần nhất</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<div class="copyright"><div class="container">©2018 Lorem Ipsum is simply…</div></div>

</div> <!--End #wrapper-->
<script type='text/javascript' src='assets/js/wow/wow.min.js'></script> 
<script type='text/javascript' src='assets/js/owl.carousel.min.js'></script> 
<script type='text/javascript' src='assets/js/imagesloaded.pkgd.min.js'></script> 
<script type='text/javascript' src='assets/js/script.js'></script> 
<script type='text/javascript' src='assets/js/script_owl.js'></script> 

</body></html>
