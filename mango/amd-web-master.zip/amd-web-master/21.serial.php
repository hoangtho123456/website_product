<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
<main id="main" class="section page-serial bgt0"  >
  <div class="container"> 
    <div class=" max570">






      <div class="section-header  text-center">
        <h1 class="section-title page-title"><span>Kiểm tra hàng chính hãng</span></h1>
      </div>

      <form action="" class="labelblock text-center">



            <label class="rowlabel">
              <span>Nhập số Seri sản phẩm của bạn</span>
              <input placeholder="Nhập số Seri sản phẩm của bạn" type="text" class="input">
            </label>

            <label class="rowlabel">
              <span>Vui lòng nhập mã dưới đây</span>
              <p><img class="" src="assets/images/captchar.jpg"  /></p>
              <p><input placeholder="Vui lòng nhập mã dưới đây" type="text" class="input"></p>
              
            </label>
            <p> <span class="reload"><img  class="" src="assets/images/reload.svg"  /> Làm mới mã</span></p>

            <p><button class="btn"><span>Gửi liên hệ</span></button></p>




      </form>





    </div>
 
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

