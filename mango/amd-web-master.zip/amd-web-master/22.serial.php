<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
<main id="main" class="section page-serial-2 bgt0"  >
  <div class="container"> 
    <div class=" max570">






      <div class="section-header text-center">
        <h1><span>Kiểm tra hàng chính hãng</span></h1>
      </div>  

      <div class="divtext">
        <p class="text-center">Sản phẩm này là hàng chính hãng của AMD</p>
        <p>Ornare pellentesque tempor tempor.
sollicitudin sociis duis dapibus Magna consequat a duis lectus neque: Interdum aliquam sagittis!
Nullam cursus euismod augue.
Hymenaeos class dapibus class quam.
Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec.</p>
      </div>
      




    </div>
 
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

