<?php include 'include/index-top.php';?>

<section class=" lazy lazy-hidden bgCover am45" data-lazy-type="bg" data-lazy-src="assets/images/bg-21.jpg" >
  <div class="container"> 
      <div class="max570">

      <div class="section-header">
        <h2> <span>SUPPORT</span>  </h2>
        <p>Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur. Sociosqu facilisi eu pretium!</p>
      </div>
    </div>  

  </div>
</section>   

<main id="main" class=" page-support bgt0 section" >
  <div class="container entry-content"> 
    <div class="max570">
      <form action="" class="labelblock">
        <div class="row">
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Họ và tên</span>
              <input placeholder="Họ và tên" type="text" class="input">
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Email</span>
              <input placeholder="Email" type="email" class="input">
            </label>
          </div>          
          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Điện thoại</span>
              <input placeholder="Điện thoại" type="text" class="input">
            </label>
          </div>

          <div class="col-sm-6 col-md-6">
            <label class="rowlabel">
              <span>Địac chỉ</span>
              <input placeholder="Email" type="text" class="input">
            </label>
          </div>          
          <div class="col-sm-12 col-md-12">
            <label class="rowlabel">
              <span>Nội dung</span>
              <textarea name="" id="" cols="30" rows="10" class="input"></textarea>
            </label>
          </div>
          <div class="col-sm-6 col-md-6">
            <button class="btn"><span>Gửi liên hệ</span></button>
          </div>
        </div>
      </form>
    </div>  
  </div>
    
</main>  
<?php include 'include/index-bottom.php';?>

