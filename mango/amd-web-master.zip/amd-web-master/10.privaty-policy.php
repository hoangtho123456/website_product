<?php include 'include/index-top.php';?>

<section class=" lazy lazy-hidden bgCover am45" data-lazy-type="bg" data-lazy-src="assets/images/bg-20.jpg" >
  <div class="container"> 

      <div class="section-header">
        <h2> <span>CHÍNH SÁCH BẢO HÀNH</span>  </h2>
      </div>

  </div>
</section>   

<main id="main" class=" page-privaty-policy bgt0 section" >
  <div class="container entry-content max970"> 
     


    <ul class="list-arrow">
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>
      <li>
        <h5 class="uppercase">Ornare pellentesque tempor tempor, sollicitudin sociis duis dapibus.</h5>
        <p>Magna consequat a duis lectus neque: Interdum aliquam sagittis! Nullam cursus euismod augue. Hymenaeos class dapibus class quam... Proin fames diam: Scelerisque dictum consequat diam pharetra ipsum nec... Eu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac?</p>
      </li>

    </ul>




  </div>
    
</main>  

<?php include 'include/index-bottom.php';?>

