<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
<main id="main" class="page-news-detail" >
  <div class="container"> 
    <div class="top-page-detail">
        <div class="breadcrumb"><a href="#">Trang chủ</a> | <a href="#">Tin tức</a> | <span>Exclusive Beachfront Luxury Apartment, Hyatt Regency</span></div>
        <div class="date">23 Mar 2018</div>
    </div>
      <div class=" text-center section-b">
        <h1 >Exclusive Beachfront Luxury Apartment, Hyatt Regency</h1>
      </div>    
    <div class="entry-content max970">
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
      <p><img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="https://via.placeholder.com/970x500" alt="alt" /></p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dignissim velit taciti litora a hendrerit eu; Class metus velit urna per sit nibh. Elementum libero proin tellus; Porta elementum enim sit venenatis per parturient sit. Tempus augue mus pretium fusce tristique ac? Montes hymenaeos commodo vitae auctor odio pretium hac. Nonummy sociis metus cursus habitant facilisi, et cum etiam nonummy... Fermentum nascetur pulvinar nascetur... Sociosqu facilisi eu pretium! Erat non eget primis primis habitasse ultrices primis... Porttitor sodales...</p>
    </div>
    <section class=" am24">
      <h4>Các bài viết liên quan</h4>
        <div class="row layout-1">
          <?php
          for($i=1;$i<=3;$i++){ 
            $img = 'https://via.placeholder.com/360x250';
            $title = 'Công nghệ AMD SenseMI';
            $desc = 'Được kiến tạo dựa trên công nghệ AMD SenseMI mang đến một bộ vi xử lý thông minh đúng nghĩa. Hiệu năng nâng cấp mạnh mẽ hơn với';
            ?>
            <div class="col-sm-4 col-md-4">
              <?php include 'repeat/layout-1.php';?>
            </div>  
          <?php
          }?>
        </div>   
    </section>       
  </div>


  

</main>



<?php include 'include/index-bottom.php';?>

