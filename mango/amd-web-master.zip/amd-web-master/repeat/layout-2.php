<div class="item">
  <a href="#" class="img">
    <img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="<?php echo $img; ?>" alt="alt" />
  </a>
  <div class="divtext">
	  <a href="#" class="title"><?php echo $title.' '.$i; ?></a>
	  <p class="desc"><?php echo $desc; ?></p>
	  <a href="#" class="more btn "><span>Xem chi tiết</span></a>
  </div>
</div>