<div class="item">
  <a href="#" class="img tRes_70">
    <img class="lazy lazy-hidden " src="assets/images/blank.png" data-lazy-type="image" data-lazy-src="<?php echo $img; ?>" alt="alt" />
  </a>
  <a href="#" class="title"><?php echo $title.' '.$i; ?></a>
  <div class="desc"><?php echo $desc; ?></div>

  <ul class="list-arrow">
    <li>8 nhân</li>
    <li>16 luồng</li>
    <li>20 MB bộ nhớ cache</li>
  </ul> 
            
</div>