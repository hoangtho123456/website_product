<?php include 'include/index-top.php';?>
<div class="afterHeader"></div>
<main id="main" class="section page-404 "  >
  <div class="container"> 
    <div class=" text-center">

      <p><img   src="assets/images/404.png"  alt="alt" /></p>
      <p class="desc">Trang này không tồn tại</p>
      <a href="#" class="btn"><span>Quay về trang chủ</span></a>
    </div>
  </div>
</main>

<?php include 'include/index-bottom.php';?>

